import streamlit as st
import joblib
import pandas as pd
import spacy
import zipfile
import re
from io import BytesIO
import tempfile
from docx import Document
import os
from pdfminer.high_level import extract_text
from concurrent.futures import ThreadPoolExecutor
import logging
from typing import List, Dict, Set, Optional
import datetime
import plotly.express as px
import plotly.graph_objects as go

# Configure Logging
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)

# Page Configuration
st.set_page_config(layout="wide", page_title="Smart Resume AI - Recruiter Portal", initial_sidebar_state="expanded")

# Load Models
try:
    nlp = spacy.load("en_core_web_sm")
    ats_model = joblib.load("ats_model.pkl")
    vectorizer = joblib.load("tfidf_vectorizer.pkl")
except Exception as e:
    st.error(f"Failed to load models: {e}")
    logger.error(f"Model loading error: {e}")
    st.stop()

# Keyword Definitions
EDUCATION_KEYWORDS = {
    "Schooling": ["class x", "10th", "high school", "secondary school", "ssc", "matriculation", "cbse", "icse", "xth class", "xth", "10th class", "school", "tenth", "secondary", "matric", "schooling"],
    "Intermediate": ["class xii", "12th", "intermediate", "higher secondary", "hsc", "xiith class", "xiith", "12th class", "senior secondary", "pre-university", "puc", "mpc intermediate"],
    "Bachelors": ["bachelor of technology", "btech", "b.tech", "bachelor of science", "bs", "bsc", "bachelor of engineering", "be", "b.e", "undergraduate", "graduation", "degree", "b.a", "ba", "b.s", "b.com"],
    "Masters": ["master of technology", "mtech", "m.tech", "master of science", "ms", "msc", "master of business administration", "mba", "postgraduate", "m.s", "m.a", "ma"],
    "PhD": ["doctor of philosophy", "phd", "ph.d", "doctorate"],
    "Certifications": ["diploma", "associate degree", "certificate", "certification"]
}

TECHNICAL_SKILLS = {
    "Programming": ["c", "c++", "java", "python", "javascript", "ruby", "go", "r", "kotlin", "swift", "perl", "php", "scala"],
    "Web": ["html", "css", "node.js", "react", "django", "flask", "angular", "vue.js", "php", "bootstrap", "streamlit"],
    "Databases": ["mysql", "mongodb", "postgresql", "sqlite", "oracle", "sql server", "nosql"],
    "Frameworks": ["pandas", "numpy", "tensorflow", "pytorch", "scikit-learn", "spring", "django", "flask", "react", "angular", "streamlit"],
    "Cloud": ["aws", "google cloud", "azure", "heroku", "docker", "kubernetes"],
    "Tools": ["git", "github", "jenkins", "jira", "vscode", "intellij", "eclipse", "linux", "windows", "macos", "xcode", "android studio", "xampp"],
    "Mobile Development": ["android", "ios", "flutter", "react native"]
}

PROJECT_KEYWORDS = ["project", "developed", "created", "built", "implemented", "designed", "worked on", "contributed to", "participated in"]
INTERNSHIP_KEYWORDS = ["internship", "intern", "trainee", "apprentice", "work experience", "placement", "co-op", "practicum"]
SECTION_HEADERS = ["education", "experience", "skills", "projects", "internships", "certifications", "awards", "publications", "languages", "interests", "summary", "objective", "work experience", "coursework"]
SCORE_PATTERN = re.compile(r"(?i)(?:gpa|cgpa|percentage|marks|score|out of)[:\s-]*([\d\.]+(?:/\s*[\d\.]+)?%?)(?:\s*(?:out of|\/)\s*([\d\.]+))?|([\d\.]+)\s*(?:out of|\/)\s*([\d\.]+)|([\d\.]+)%")

GENERAL_TO_SPECIFIC = {
    "frameworks": ["django", "react", "spring boot", "angular"],
    "cloud": ["aws", "google cloud", "azure"],
    "data science": ["python", "pandas", "tensorflow", "pytorch"]
}

# Helper Functions
def extract_text_from_file(file: BytesIO, file_type: str) -> str:
    try:
        if file_type == "application/pdf":
            return extract_text(BytesIO(file.read()))
        elif file_type == "application/vnd.openxmlformats-officedocument.wordprocessingml.document":
            doc = Document(BytesIO(file.read()))
            return "\n".join(para.text for para in doc.paragraphs)
        else:
            raise ValueError(f"Unsupported file type: {file_type}")
    except Exception as e:
        logger.error(f"Text extraction failed: {e}")
        raise

def is_resume(text: str) -> bool:
    text_lower = text.lower()
    sections = ["education", "experience", "skills", "projects", "internships"]
    section_count = sum(section in text_lower for section in sections)
    all_keywords = ([kw for category in EDUCATION_KEYWORDS.values() for kw in category] +
                    [skill for skills in TECHNICAL_SKILLS.values() for skill in skills] +
                    PROJECT_KEYWORDS + INTERNSHIP_KEYWORDS)
    keyword_count = sum(kw in text_lower for kw in all_keywords)
    return section_count >= 2 or keyword_count >= 5

def extract_sections(text: str) -> Dict[str, str]:
    lines = text.split("\n")
    sections = {}
    current_section = None
    for line in lines:
        line_lower = line.lower().strip()
        for header in SECTION_HEADERS:
            if header in line_lower and len(line_lower.split()) < 6:
                current_section = header
                sections[current_section] = []
                break
        else:
            if current_section:
                sections[current_section].append(line)
    for section in sections:
        sections[section] = "\n".join(sections[section]).strip()
    return sections

def normalize_score(score_str: str, education_level: str) -> Optional[float]:
    score_str = score_str.lower()
    try:
        if '%' in score_str:
            match = re.search(r'(\d+\.?\d*)%', score_str)
            return float(match.group(1)) if match else None
        match = re.search(r'(\d+\.?\d*)\s*/\s*(\d+\.?\d*)', score_str)
        if match:
            score, max_score = float(match.group(1)), float(match.group(2))
            if max_score == 4.0:
                return (score / 4.0) * 100
            elif max_score == 10.0:
                return (score / 10.0) * 100
            return (score / max_score) * 100
        match = re.search(r'(gpa|cgpa|score|marks)[:\s-]*(\d+\.?\d*)', score_str)
        if match:
            score = float(match.group(2))
            if score <= 4.0:
                return (score / 4.0) * 100
            elif score <= 10.0:
                return (score / 10.0) * 100
            return score if score <= 100 else None
        match = re.search(r'(\d+\.?\d*)', score_str)
        if match:
            score = float(match.group(1))
            if education_level in ["Schooling", "Intermediate"]:
                if score <= 10.0:
                    return (score / 10.0) * 100
                return score if score <= 100 else None
            else:
                if score <= 4.0:
                    return (score / 4.0) * 100
                elif score <= 10.0:
                    return (score / 10.0) * 100
                return score if score <= 100 else None
        return None
    except (ValueError, ZeroDivisionError) as e:
        logger.warning(f"Failed to normalize score '{score_str}': {e}")
        return None

def extract_education(text: str) -> List[Dict[str, Optional[str]]]:
    sections = extract_sections(text)
    education_text = sections.get("education", sections.get("coursework", text))
    lines = education_text.split("\n")
    education_entries = []
    current_entry = []
    for line in lines:
        line_lower = line.strip().lower()
        if line.strip():
            if any(kw in line_lower for category in EDUCATION_KEYWORDS.values() for kw in category):
                if current_entry:
                    education_entries.append("\n".join(current_entry))
                current_entry = [line]
            else:
                current_entry.append(line)
        elif current_entry:
            education_entries.append("\n".join(current_entry))
            current_entry = []
    if current_entry:
        education_entries.append("\n".join(current_entry))
    education_details = []
    for entry in education_entries:
        doc = nlp(entry)
        degree = next((cat for cat, kws in EDUCATION_KEYWORDS.items() if any(kw in entry.lower() for kw in kws)), "")
        institution = next((ent.text for ent in doc.ents if ent.label_ == "ORG"), None) or \
                      (re.search(r"(?:university|college|school|institute|academy|board)\s+of?\s+[\w\s]+", entry, re.I).group(0) if re.search(r"(?:university|college|school|institute|academy|board)\s+of?\s+[\w\s]+", entry, re.I) else " ")
        year_match = re.search(r"\b(?:19|20)\d{2}\s*-\s*(?:19|20)\d{2}\b|\b(?:19|20)\d{2}\b", entry)
        year = year_match.group(0) if year_match else ""
        major_match = re.search(r"(?:in|major|specialization)[:\s]+([a-z\s]+)", entry, re.I)
        major = major_match.group(1).strip() if major_match else ""
        score_match = SCORE_PATTERN.search(entry)
        if score_match:
            score_str = score_match.group(0)
            normalized_score = normalize_score(score_str, degree)
            score_display = f"{score_str} ({normalized_score:.1f}%)" if normalized_score is not None else score_str
        else:
            score_display = " "
            normalized_score = None
        education_details.append({"degree": degree, "institution": institution, "major": major, "score": score_display, "normalized_score": normalized_score, "year": year})
    return education_details

def extract_skills(text: str, required_skills: List) -> Set[str]:
    skills = set()
    text_lower = text.lower()
    for category, skill_list in TECHNICAL_SKILLS.items():
        for skill in skill_list:
            if re.search(rf"\b{re.escape(skill)}\b", text_lower):
                skills.add(skill)
    for skill in required_skills:
        skill_str = skill if isinstance(skill, str) else " or ".join(skill)
        if re.search(rf"\b{re.escape(skill_str)}\b", text_lower):
            if isinstance(skill, list):
                skills.update(skill)
            else:
                skills.add(skill)
    return skills

def extract_projects(text: str) -> List[Dict[str, str]]:
    sections = extract_sections(text)
    project_text = sections.get("projects", text)
    lines = project_text.split("\n")
    projects = []
    current_project = []
    for line in lines:
        line_lower = line.lower().strip()
        if (any(kw in line_lower for kw in PROJECT_KEYWORDS) or re.match(r"^\s*[-•*]\s+", line)) and line.strip():
            if current_project:
                projects.append("\n".join(current_project))
            current_project = [line]
        elif current_project and line.strip():
            current_project.append(line)
        elif current_project and not line.strip():
            projects.append("\n".join(current_project))
            current_project = []
    if current_project:
        projects.append("\n".join(current_project))
    project_details = []
    for project in projects:
        title_match = re.search(r"^\s*[-•*]?\s*(.+?)(?:[-:]\s*|$)", project)
        title = title_match.group(1).strip() if title_match else "Unnamed Project"
        techs = set(skill for skill_list in TECHNICAL_SKILLS.values() for skill in skill_list if skill in project.lower())
        tech_str = ", ".join(techs) if techs else "N/A"
        desc_match = re.search(r"(?:\n|\s{2,})(.+)", project, re.DOTALL)
        description = desc_match.group(1).strip() if desc_match else project.strip()
        duration_match = re.search(r"(?:(?:19|20)\d{2}\s*[-–]\s*(?:19|20)?\d{2})", project)
        duration = duration_match.group(0) if duration_match else " "
        project_details.append({"title": title, "technologies": tech_str, "description": description, "duration": duration})
    return project_details

def extract_internships(text: str) -> List[Dict[str, str]]:
    sections = extract_sections(text)
    intern_text = sections.get("internships", sections.get("experience", sections.get("work experience", text)))
    lines = intern_text.split("\n")
    internships = []
    current_internship = []
    for line in lines:
        line_lower = line.lower().strip()
        if (any(kw in line_lower for kw in INTERNSHIP_KEYWORDS) or re.match(r"^\s*[-•*]\s+", line)) and line.strip():
            if current_internship:
                internships.append("\n".join(current_internship))
            current_internship = [line]
        elif current_internship and line.strip():
            current_internship.append(line)
        elif current_internship and not line.strip():
            internships.append("\n".join(current_internship))
            current_internship = []
    if current_internship:
        internships.append("\n".join(current_internship))
    internship_details = []
    for internship in internships:
        doc = nlp(internship)
        role_match = re.search(r"^\s*[-•*]?\s*(.+?)(?:\s*(?:at|with)\s+|$)", internship)
        company_match = re.search(r"(?:at|with)\s+(.+?)(?:\s*[-:]\s*|\n|$)", internship, re.I)
        role = role_match.group(1).strip() if role_match else "Unnamed Role"
        company = company_match.group(1).strip() if company_match else next((ent.text for ent in doc.ents if ent.label_ == "ORG"), "Unknown Company")
        techs = set(skill for skill_list in TECHNICAL_SKILLS.values() for skill in skill_list if skill in internship.lower())
        tech_str = ", ".join(techs) if techs else "N/A"
        desc_match = re.search(r"(?:\n|\s{2,})(.+)", internship, re.DOTALL)
        description = desc_match.group(1).strip() if desc_match else internship.strip()
        duration_match = re.search(r"(?:(?:19|20)\d{2}\s*[-–]\s*(?:19|20)?\d{2})", internship)
        duration = duration_match.group(0) if duration_match else " "
        internship_details.append({"role": role, "company": company, "technologies": tech_str, "description": description, "duration": duration})
    return internship_details

def extract_experience(text: str) -> List[Dict[str, str]]:
    sections = extract_sections(text)
    experience_text = sections.get("experience", sections.get("work experience", text))
    lines = experience_text.split("\n")
    experiences = []
    current_experience = []
    for line in lines:
        line_lower = line.lower().strip()
        if (re.match(r"^\s*[-•*]\s+", line) or any(kw in line_lower for kw in ["role", "position", "job"])) and line.strip():
            if current_experience:
                experiences.append("\n".join(current_experience))
            current_experience = [line]
        elif current_experience and line.strip():
            current_experience.append(line)
        elif current_experience and not line.strip():
            experiences.append("\n".join(current_experience))
            current_experience = []
    if current_experience:
        experiences.append("\n".join(current_experience))
    experience_details = []
    for experience in experiences:
        doc = nlp(experience)
        role_match = re.search(r"^\s*[-•*]?\s*(.+?)(?:\s*(?:at|with)\s+|$)", experience)
        company_match = re.search(r"(?:at|with)\s+(.+?)(?:\s*[-:]\s*|\n|$)", experience, re.I)
        role = role_match.group(1).strip() if role_match else "Unnamed Role"
        company = company_match.group(1).strip() if company_match else next((ent.text for ent in doc.ents if ent.label_ == "ORG"), "Unknown Company")
        techs = set(skill for skill_list in TECHNICAL_SKILLS.values() for skill in skill_list if skill in experience.lower())
        tech_str = ", ".join(techs) if techs else "N/A"
        desc_match = re.search(r"(?:\n|\s{2,})(.+)", experience, re.DOTALL)
        description = desc_match.group(1).strip() if desc_match else experience.strip()
        duration_match = re.search(r"(?:(?:19|20)\d{2}\s*[-–]\s*(?:19|20)?\d{2})", experience)
        duration = duration_match.group(0) if duration_match else " "
        experience_details.append({"role": role, "company": company, "technologies": tech_str, "description": description, "duration": duration})
    return experience_details

def process_file(file: BytesIO, file_name: str, file_type: str) -> tuple[str, Optional[str]]:
    try:
        text = extract_text_from_file(file, file_type)
        return file_name, text
    except ValueError as e:
        logger.error(f"Unsupported file type for {file_name}: {e}")
        st.warning(f"Skipping {file_name}: Unsupported file type.")
        return file_name, None
    except Exception as e:
        logger.error(f"Error processing {file_name}: {e}")
        st.warning(f"Skipping {file_name}: Processing error - file may be corrupted.")
        return file_name, None

# Login Page
def login_page():
    with st.form("login"):
        st.markdown("#### Enter your credentials")
        email = st.text_input("Email")
        password = st.text_input("Password", type="password")
        submit = st.form_submit_button("Login")
        if submit:
            if email == "admin" and password == "password":  # Replace with secure authentication
                st.session_state['logged_in'] = True
                st.rerun()
            else:
                st.error("Login failed: Invalid email or password")

# Parse Job Description
def parse_jd(jd_text: str) -> Dict[str, any]:
    education_requirements = {}
    skills_required = []
    preferred_skills = []

    education_pattern = r"(Schooling|Intermediate|Bachelors|Masters|PhD|Certifications):\s*Minimum\s*(\d+\.?\d*)\s*(%|CGPA)?"
    matches = re.finditer(education_pattern, jd_text, re.I)
    for match in matches:
        level = match.group(1).capitalize()
        score_str = match.group(2)
        unit = match.group(3)
        try:
            score = float(score_str)
            if unit == '%':
                required_percentage = score
            elif unit == 'CGPA':
                required_percentage = (score / 10.0) * 100
            else:
                required_percentage = score
            education_requirements[level] = required_percentage
        except ValueError:
            logger.warning(f"Invalid score value '{score_str}' for {level}")

    skills_section = re.search(r"Skills Required:(.*?)(?:Preferred Qualifications:|Responsibilities:|$)", jd_text, re.I | re.DOTALL)
    if skills_section:
        skills_text = skills_section.group(1).strip()
        category_pattern = r"(\w+):\s*([\w, ]+)"
        category_matches = re.finditer(category_pattern, skills_text)
        for match in category_matches:
            skills_str = match.group(2)
            if " or " in skills_str.lower():
                or_skills = [skill.strip().lower() for skill in skills_str.split(" or ")]
                skills_required.append(or_skills)
            else:
                skills_required.extend([skill.strip().lower() for skill in skills_str.split(",")])
        if not category_matches:
            skills_required.extend([skill.strip().lower() for skill in skills_text.split(",")])

    preferred_section = re.search(r"Preferred Qualifications:(.*?)(?:Responsibilities:|Location:|$)", jd_text, re.I | re.DOTALL)
    if preferred_section:
        preferred_text = preferred_section.group(1).strip()
        preferred_skills = [skill.strip().lower() for skill in preferred_text.split(",") if skill.strip()]

    for general_term, specific_skills in GENERAL_TO_SPECIFIC.items():
        if re.search(rf"\b{general_term}\b", jd_text.lower(), re.I) and not re.search(rf"\b{general_term}\s+like\b", jd_text.lower(), re.I):
            skills_required.extend(specific_skills)

    return {
        "education_requirements": education_requirements,
        "skills_required": skills_required,
        "preferred_skills": preferred_skills,
        "ats_score_threshold": 0
    }

# Parse Structured Query
def parse_job_criteria(query: str) -> Dict[str, any]:
    doc = nlp(query.lower())
    education_requirements = {}
    skills_required = []
    ats_score_threshold = 0

    education_pattern = re.compile(r"(\bschooling\b|\binter(?:mediate)?\b|\bbachelors?\b|\bmasters?\b|\bphd\b|\bcertifications?\b)\s*(?:above|with|having)?\s*(\d+\.?\d*)\s*(%|gpa)?", re.I)
    for match in education_pattern.finditer(query):
        level = match.group(1).capitalize()
        score_str = match.group(2)
        unit = match.group(3)
        try:
            score = float(score_str)
            if unit == '%':
                required_percentage = score
            elif unit == 'gpa':
                required_percentage = (score / 4.0) * 100 if score <= 4.0 else (score / 10.0) * 100
            else:
                if level in ["Schooling", "Intermediate"]:
                    required_percentage = score if score <= 100 else (score / 10.0) * 100
                else:
                    required_percentage = score if score <= 100 else (score / 4.0 if score <= 4.0 else score / 10.0) * 100
            education_requirements[level] = max(0, min(required_percentage, 100))
        except ValueError:
            logger.warning(f"Invalid score value '{score_str}' for {level}")

    skill_keywords = set(skill for skills in TECHNICAL_SKILLS.values() for skill in skills)
    for token in doc:
        token_text = token.text.lower()
        if token_text in skill_keywords:
            skills_required.append(token_text)

    ats_match = re.search(r"ats\s*(?:score)?\s*(?:above)?\s*(\d+)", query, re.I)
    if ats_match:
        ats_score_threshold = int(ats_match.group(1))

    skills_required = list(set(skills_required))
    return {
        "education_requirements": education_requirements,
        "skills_required": skills_required,
        "preferred_skills": [],
        "ats_score_threshold": ats_score_threshold
    }

# Dashboard Page
def dashboard_page():
    """Render the dashboard page with enhanced visualizations."""
    if 'all_candidates' not in st.session_state:
        st.warning("No data available. Please process resumes on the main page first.")
        if st.button("Go to Main Page"):
            st.session_state['page'] = 'main'
            st.rerun()
        return

    df_all = st.session_state['all_candidates']
    shortlisted_df = st.session_state['shortlisted_candidates']
    skills_required = st.session_state.get('skills_required', [])

    st.title("📈 Recruitment Dashboard")
    st.markdown("**Explore interactive insights into your candidate pool.**")

    # Overview Metrics
    total_resumes = len(df_all)
    shortlisted_count = len(shortlisted_df)
    percent_shortlisted = (shortlisted_count / total_resumes * 100) if total_resumes > 0 else 0
    percent_education_met = (sum(df_all['Education Met']) / total_resumes * 100) if total_resumes > 0 else 0
    percent_skills_met = (sum(df_all['Skills Met']) / total_resumes * 100) if total_resumes > 0 else 0
    percent_ats_met = (sum(df_all['ATS Met']) / total_resumes * 100) if total_resumes > 0 else 0
    avg_ats_score = df_all['ATS Score'].mean()
    avg_match_score = df_all['Match Score'].mean() * 100  # Convert to percentage

    st.subheader("Overview Metrics")
    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.metric("Total Resumes", total_resumes)
    with col2:
        st.metric("Shortlisted Candidates", shortlisted_count)
    with col3:
        st.metric("Percentage Shortlisted", f"{percent_shortlisted:.2f}%")
    with col4:
        st.metric("Average ATS Score", f"{avg_ats_score:.2f}")

    # Score Distributions
    st.subheader("Score Distributions")
    col5, col6 = st.columns(2)
    with col5:
        fig_ats = px.histogram(df_all, x='ATS Score', nbins=20, title="ATS Score Distribution", color_discrete_sequence=['#1f77b4'])
        st.plotly_chart(fig_ats, use_container_width=True)
    with col6:
        fig_match_violin = px.violin(df_all, y='Match Score', box=True, points='all', title="Match Score Violin Plot", color_discrete_sequence=['#ff7f0e'])
        st.plotly_chart(fig_match_violin, use_container_width=True)

    # Skills Analysis
    st.subheader("Skills Analysis")
    all_skills = []
    for skills_str in df_all['Skills']:
        if skills_str != "N/A":
            skills = [skill.strip().lower() for skill in skills_str.split(",")]
            all_skills.extend(skills)
    skill_counts = pd.Series(all_skills).value_counts().head(10)
    fig_skills = px.bar(skill_counts, x=skill_counts.index, y=skill_counts.values, title="Top 10 Skills Among Candidates",
                        color=skill_counts.values, color_continuous_scale='Viridis')
    st.plotly_chart(fig_skills, use_container_width=True)

    # Skills Gap Analysis
    if skills_required:
        st.subheader("Skills Gap Analysis")
        skills_gap = {}
        for skill in skills_required:
            if isinstance(skill, list):
                has_skill = df_all['Skills'].apply(lambda x: any(s.lower() in x.lower() for s in skill))
            else:
                has_skill = df_all['Skills'].apply(lambda x: skill.lower() in x.lower())
            percent = (sum(has_skill) / total_resumes * 100) if total_resumes > 0 else 0
            skills_gap[skill if isinstance(skill, str) else " or ".join(skill)] = percent
        fig_gap = px.bar(x=list(skills_gap.keys()), y=list(skills_gap.values()), title="Percentage of Candidates with Required Skills",
                         color=list(skills_gap.values()), color_continuous_scale='Plasma')
        st.plotly_chart(fig_gap, use_container_width=True)
    else:
        st.info("No specific skills required in the job criteria.")

    # Education Levels
    st.subheader("Education Levels Distribution")
    education_levels = []
    for education_str in df_all['Education']:
        if education_str != "N/A":
            first_entry = education_str.split(";")[0]
            degree = first_entry.split(" - ")[0].strip().lower()
            education_levels.append(degree)
    education_counts = pd.Series(education_levels).value_counts()
    fig_education = px.pie(education_counts, values=education_counts.values, names=education_counts.index, title="Education Levels",
                           color_discrete_sequence=px.colors.qualitative.Set2)
    st.plotly_chart(fig_education, use_container_width=True)

    # Experience Analysis
    st.subheader("Experience Analysis")
    has_projects = sum(df_all['Projects'] != 'N/A')
    has_internships = sum(df_all['Internships'] != 'N/A')
    has_experiences = sum(df_all['Experience'] != 'N/A')
    experience_data = pd.DataFrame({
        'Category': ['Projects', 'Internships', 'Experiences'],
        'Count': [has_projects, has_internships, has_experiences]
    })
    fig_experience = px.bar(experience_data, x='Category', y='Count', title="Candidates with Projects, Internships, or Experiences",
                            color='Category', color_discrete_sequence=px.colors.qualitative.Bold)
    st.plotly_chart(fig_experience, use_container_width=True)

    # New Visualization: ATS vs Match Score Scatter
    st.subheader("ATS vs Match Score Correlation")
    fig_scatter = px.scatter(df_all, x='ATS Score', y='Match Score', color='Is Shortlisted',
                             title="ATS Score vs Match Score", color_discrete_map={True: '#2ca02c', False: '#d62728'},
                             hover_data=['Candidate Name'])
    st.plotly_chart(fig_scatter, use_container_width=True)

    # New Visualization: Skill Co-occurrence Heatmap (Top 5 Skills)
    st.subheader("Skill Co-occurrence Heatmap (Top 5 Skills)")
    top_5_skills = skill_counts.head(5).index.tolist()
    co_occurrence = pd.DataFrame(0, index=top_5_skills, columns=top_5_skills)
    for skills_str in df_all['Skills']:
        if skills_str != "N/A":
            skills_list = [skill.strip().lower() for skill in skills_str.split(",")]
            for i in top_5_skills:
                if i in skills_list:
                    for j in top_5_skills:
                        if j in skills_list and i != j:
                            co_occurrence.loc[i, j] += 1
    fig_heatmap = go.Figure(data=go.Heatmap(z=co_occurrence.values, x=co_occurrence.columns, y=co_occurrence.index,
                                            colorscale='Blues'))
    fig_heatmap.update_layout(title="Skill Co-occurrence Among Top 5 Skills")
    st.plotly_chart(fig_heatmap, use_container_width=True)

    # New Visualization: Experience Over Time (if duration data is reliable)
    st.subheader("Experience Timeline")
    years = []
    for col in ['Projects', 'Internships', 'Experience']:
        for entry in df_all[col]:
            if entry != "N/A":
                for item in entry.split(";"):
                    year_match = re.search(r"(?:(?:19|20)\d{2})", item)
                    if year_match:
                        years.append(int(year_match.group(0)))
    if years:
        year_counts = pd.Series(years).value_counts().sort_index()
        fig_timeline = px.line(x=year_counts.index, y=year_counts.values, title="Experience Entries Over Time",
                               labels={'x': 'Year', 'y': 'Number of Entries'})
        st.plotly_chart(fig_timeline, use_container_width=True)
    else:
        st.info("No reliable year data extracted from experience sections.")

# Main Function
def main():
    st.markdown(
        """
        <style>
        .stButton>button {
            background-color: transparent;
            color: #1f77b4;
            border: 1px solid #1f77b4;
            width: 100%;
            padding: 10px;
            font-size: 16px;
        }
        .stButton>button:hover {
            background-color: #e6f7ff;
        }
        </style>
        """,
        unsafe_allow_html=True
    )

    if 'logged_in' not in st.session_state:
        st.session_state['logged_in'] = False
    if 'page' not in st.session_state:
        st.session_state['page'] = 'main'

    # Sidebar Navigation
    with st.sidebar:
        st.header("Navigation")
        if st.button("Dashboard"):
            st.session_state['page'] = 'dashboard'
            st.rerun()
        if st.session_state['page'] == 'dashboard':
            if st.button("Back to Main"):
                st.session_state['page'] = 'main'
                st.rerun()

    if not st.session_state['logged_in']:
        login_page()
    elif st.session_state['page'] == 'main':
        st.title("📊 Smart Resume AI - Recruiter Portal")
        st.markdown("**Analyze and shortlist candidates with precision using AI-powered resume parsing.**")

        with st.sidebar:
            st.header("🔍 Job Criteria")
            input_type = st.radio("Input Type", ["Structured Criteria", "Job Description"])
            if input_type == "Structured Criteria":
                query = st.text_area(
                    "Enter structured criteria",
                    placeholder="E.g., 'Schooling 80%, Intermediate 70%, Bachelors CGPA 7.0, skills in Python, Java, ATS score above 60'",
                    help="Specify education (e.g., 'Schooling 80%'), skills, and ATS threshold."
                )
            else:
                query = st.text_area(
                    "Paste job description",
                    placeholder="Job Title: ...\nJob Description: ...\nEligibility Criteria: ...",
                    help="Paste the full job description starting with 'Job Title:'."
                )

        # File Uploader
        if 'file_uploader_key' not in st.session_state:
            st.session_state['file_uploader_key'] = 0

        uploaded_files = st.file_uploader(
            "Upload Resumes (PDF or DOCX)",
            type=["pdf", "docx"],
            accept_multiple_files=True,
            key=f"file_uploader_{st.session_state['file_uploader_key']}"
        )

        if st.button("Clear Uploaded Files"):
            st.session_state['file_uploader_key'] += 1
            if 'shortlisted_candidates' in st.session_state:
                del st.session_state['shortlisted_candidates']
            st.rerun()

        if not uploaded_files:
            st.info("Please upload resumes (PDF or DOCX) to begin processing.")
            return

        # Process Files
        resume_texts = []
        invalid_files = []
        with st.spinner("Processing resumes..."):
            progress_bar = st.progress(0)
            total_files = len(uploaded_files)
            with ThreadPoolExecutor() as executor:
                for i, uploaded_file in enumerate(uploaded_files):
                    file_name, text = process_file(uploaded_file, uploaded_file.name, uploaded_file.type)
                    if text and is_resume(text):
                        resume_texts.append((file_name, text))
                    else:
                        invalid_files.append(file_name)
                    progress_bar.progress((i + 1) / total_files)
            st.success(f"Processed {len(resume_texts)} resumes successfully.")

        # Parse Criteria
        criteria = parse_jd(query) if input_type == "Job Description" else parse_job_criteria(query) if query else {
            "education_requirements": {},
            "skills_required": [],
            "preferred_skills": [],
            "ats_score_threshold": 0
        }
        education_requirements = criteria["education_requirements"]
        skills_required = criteria["skills_required"]
        preferred_skills = criteria["preferred_skills"]
        ats_score_threshold = criteria["ats_score_threshold"]

        # Store skills_required in session state
        st.session_state['skills_required'] = skills_required

        # Process All Candidates
        all_candidates = []
        for file_name, text in resume_texts:
            try:
                education = extract_education(text)
                skills = extract_skills(text, skills_required)
                projects = extract_projects(text)
                internships = extract_internships(text)
                experiences = extract_experience(text)
                text_vector = vectorizer.transform([text])
                ats_score = round(float(ats_model.predict(text_vector)[0]) * 100, 2)

                meets_education = not education_requirements or all(
                    any(e["degree"].lower() == level.lower() and e["normalized_score"] is not None and e["normalized_score"] >= req_score
                        for e in education)
                    for level, req_score in education_requirements.items()
                )
                meets_skills = not skills_required or all(
                    any(s in [skill.lower() for skill in skills] for s in skill) if isinstance(skill, list) else skill.lower() in [s.lower() for s in skills]
                    for skill in skills_required
                )
                meets_ats = ats_score >= ats_score_threshold if ats_score_threshold else True

                education_match = sum(
                    any(e["degree"].lower() == level.lower() and e["normalized_score"] is not None and e["normalized_score"] >= req_score
                        for e in education)
                    for level, req_score in education_requirements.items()
                ) / len(education_requirements) if education_requirements else 1.0
                skills_match = sum(
                    any(s in [skill.lower() for skill in skills] for s in skill) if isinstance(skill, list) else skill.lower() in [s.lower() for s in skills]
                    for skill in skills_required
                ) / len(skills_required) if skills_required else 1.0
                ats_match = 1 if meets_ats else 0
                overall_match = (education_match + skills_match + ats_match) / 3

                candidate_data = {
                    "Candidate Name": file_name,
                    "Education": "; ".join(f"{e['degree']} - {e['institution']} (Score: {e['score']})" for e in education) or "N/A",
                    "Skills": ", ".join(skills) or "N/A",
                    "Projects": "; ".join(f"{p['title']} (Tech: {p['technologies']})" for p in projects) or "N/A",
                    "Internships": "; ".join(f"{i['role']} at {i['company']} (Tech: {i['technologies']})" for i in internships) or "N/A",
                    "Experience": "; ".join(f"{e['role']} at {e['company']} (Tech: {e['technologies']})" for e in experiences) or "N/A",
                    "ATS Score": ats_score,
                    "Match Score": overall_match,
                    "Education Met": meets_education,
                    "Skills Met": meets_skills,
                    "ATS Met": meets_ats,
                    "Is Shortlisted": (meets_education and meets_skills and meets_ats) or overall_match > 0.5
                }
                all_candidates.append(candidate_data)
            except Exception as e:
                logger.error(f"Error processing {file_name}: {e}")
                invalid_files.append(file_name)

        # Store Data in Session State
        df_all = pd.DataFrame(all_candidates)
        shortlisted_df = df_all[df_all["Is Shortlisted"]]
        st.session_state['all_candidates'] = df_all
        st.session_state['shortlisted_candidates'] = shortlisted_df

        # Display Results
        if invalid_files:
            st.error(f"Invalid or unprocessable files: {', '.join(set(invalid_files))}")

        if all_candidates:
            if not shortlisted_df.empty:
                display_df = shortlisted_df.copy()
                display_df["Education Met"] = display_df["Education Met"].map({True: "Yes", False: "No"})
                display_df["Skills Met"] = display_df["Skills Met"].map({True: "Yes", False: "No"})
                display_df["ATS Met"] = display_df["ATS Met"].map({True: "Yes", False: "No"})
                st.subheader("Shortlisted Candidates")
                st.dataframe(display_df.style.format({"ATS Score": "{:.2f}", "Match Score": "{:.2f}"}))
                st.info(f"Total shortlisted candidates: {len(shortlisted_df)}")
                csv_buffer = BytesIO()
                shortlisted_df.to_csv(csv_buffer, index=False)
                st.download_button(label="Download Shortlist CSV", data=csv_buffer.getvalue(), file_name="shortlisted_candidates.csv", mime="text/csv")
            else:
                st.warning("No candidates meet the minimum criteria. Showing top candidates based on match score.")
                top_df = df_all.sort_values(by="Match Score", ascending=False).head(10)
                display_df = top_df[["Candidate Name", "Education", "Skills", "ATS Score", "Match Score"]]
                st.dataframe(display_df.style.format({"ATS Score": "{:.2f}", "Match Score": "{:.2f}"}))
                csv_buffer = BytesIO()
                top_df.to_csv(csv_buffer, index=False)
                st.download_button(label="Download Top Candidates CSV", data=csv_buffer.getvalue(), file_name="top_candidates.csv", mime="text/csv")

            if st.button("View Dashboard"):
                st.session_state['page'] = 'dashboard'
                st.rerun()
        else:
            st.info("No valid resumes processed. Please upload valid resume files.")
    elif st.session_state['page'] == 'dashboard':
        dashboard_page()

if __name__ == "__main__":
    main()