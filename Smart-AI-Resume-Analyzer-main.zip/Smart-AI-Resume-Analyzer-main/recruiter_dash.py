import numpy as np
import pandas as pd
import streamlit as st
import plotly.graph_objects as go
import datetime

# Page Configuration
st.set_page_config(page_title='Recruitment Dashboard', page_icon=':bar_chart:', layout='wide', initial_sidebar_state="collapsed")
st.header(":bar_chart: Recruitment Dashboard")

# Data Source Selection
if 'shortlisted_candidates' in st.session_state and 'total_candidates' in st.session_state:
    is_shortlisting_data = True
    df_data = st.session_state['shortlisted_candidates'].copy()
    total_candidates = st.session_state['total_candidates']
    st.info("Using shortlisted candidates data from Resume AI.")
else:
    is_shortlisting_data = False
    st.write("Please upload a CSV file with shortlisted candidates data.")
    uploaded_file = st.file_uploader('Upload your CSV file here', type='csv')
    if uploaded_file is None:
        st.stop()
    try:
        df_data = pd.read_csv(uploaded_file, encoding_errors='ignore')
        total_candidates = st.number_input("Enter the total number of candidates considered:", min_value=0, value=0)
    except pd.errors.ParserError as e:
        st.error(f"Error parsing CSV file: {e}")
        st.stop()

# Process Data Based on Source
if is_shortlisting_data or total_candidates > 0:
    # Shortlisting Metrics Section
    st.subheader("Shortlisting Metrics")
    shortlisted_count = len(df_data)
    percentage_shortlisted = (shortlisted_count / total_candidates * 100) if total_candidates > 0 else 0
    col1, col2, col3 = st.columns(3)
    with col1:
        st.metric("Total Candidates", total_candidates)
    with col2:
        st.metric("Shortlisted Candidates", shortlisted_count)
    with col3:
        st.metric("Percentage Shortlisted", f"{percentage_shortlisted:.2f}%")

    # ATS Score Distribution
    st.subheader("ATS Score Distribution")
    fig_ats = go.Figure(data=[go.Histogram(x=df_data['ATS Score'], nbinsx=20, name='ATS Score')])
    fig_ats.update_layout(xaxis_title="ATS Score", yaxis_title="Count")
    st.plotly_chart(fig_ats, use_container_width=True)

    # Top Skills
    st.subheader("Top Skills Among Shortlisted Candidates")
    all_skills = df_data['Skills'].str.split(', ').explode().str.strip()
    top_skills = all_skills.value_counts().head(10)
    fig_skills = go.Figure(data=[go.Bar(x=top_skills.index, y=top_skills.values, name='Skill Count')])
    fig_skills.update_layout(xaxis_title="Skills", yaxis_title="Number of Candidates")
    st.plotly_chart(fig_skills, use_container_width=True)

    # Education Levels
    st.subheader("Education Levels of Shortlisted Candidates")
    education_levels = df_data['Education'].apply(lambda x: x.split(' - ')[0] if ' - ' in x else 'Unknown')
    education_counts = education_levels.value_counts()
    fig_education = go.Figure(data=[go.Pie(labels=education_counts.index, values=education_counts.values)])
    st.plotly_chart(fig_education, use_container_width=True)

# Add Recruitment-Specific Columns for Compatibility
if not is_shortlisting_data or total_candidates > 0:
    df_data['Application_Date'] = pd.to_datetime(datetime.datetime.now())
    df_data['Recruitment_Stages'] = df_data['ATS Score'].apply(lambda x: 'Hired' if x >= 75 else 'Applied')
    df_data['Hiring_Date'] = df_data['Application_Date'] + pd.Timedelta(days=30)
    df_data['Status'] = df_data['Recruitment_Stages'].apply(lambda x: 'Placement' if x == 'Hired' else 'Pending')
    df_data['Source'] = 'Resume AI'  # Default source
    df_data['Company'] = 'Unknown'
    df_data['Language'] = 'English'
    df_data['Location'] = 'Unknown'
    df_data['Gender'] = 'Unknown'

    # Date Filter
    col1, col2 = st.columns(2)
    try:
        df_data["Application_Date"] = pd.to_datetime(df_data["Application_Date"])
        startDate = pd.to_datetime(df_data["Application_Date"]).min()
        endDate = pd.to_datetime(df_data["Application_Date"]).max()
        with col1:
            date1 = pd.to_datetime(st.date_input("Start Date", startDate))
        with col2:
            date2 = pd.to_datetime(st.date_input("End Date", endDate))
        df_data = df_data[(df_data["Application_Date"] >= date1) & (df_data["Application_Date"] <= date2)]
    except:
        st.write('⚠️ Application_Date column required for date filter')

    # Sidebar Filters
    st.sidebar.header('Filter Here:')
    language = st.sidebar.multiselect("Language", options=df_data['Language'].unique(), default=df_data['Language'].unique())
    location = st.sidebar.multiselect("Location", options=df_data['Location'].unique(), default=df_data['Location'].unique())
    gender = st.sidebar.multiselect("Gender", options=df_data['Gender'].unique(), default=df_data['Gender'].unique())
    company = st.sidebar.multiselect("Company", options=df_data['Company'].unique(), default=df_data['Company'].unique())
    df_selection = df_data.query("Language == @language & Location == @location & Gender == @gender & Company == @company")

    st.sidebar.markdown("Developed by [GitHub](https://github.com/srdobolo), [LinkedIn](https://www.linkedin.com/in/joaomiguellima/)")

    # Calculate Top KPIs
    hired = df_selection['Recruitment_Stages'].value_counts().get('Hired', 0)
    apps_per_hire = len(df_selection) / hired if hired > 0 else 0
    try:
        df_days_to_hire = df_selection.loc[df_selection['Recruitment_Stages'] == 'Hired']
        df_days_to_hire[['Application_Date', 'Hiring_Date']] = df_days_to_hire[['Application_Date', 'Hiring_Date']].apply(pd.to_datetime)
        df_days_to_hire['Days_To_Hire'] = (df_days_to_hire['Hiring_Date'] - df_days_to_hire['Application_Date']).dt.days
        days_to_hire = df_days_to_hire['Days_To_Hire'].mean().round()
    except:
        days_to_hire = 0
    success_rate = (df_selection['Status'].value_counts().get('Placement', 0) / hired * 100) if hired > 0 else 0

    # KPI Gauges
    st.subheader("Recruitment KPIs")
    first_column, second_column, third_column, fourth_column = st.columns(4)
    with first_column:
        fig1 = go.Figure(go.Indicator(domain={'x': [0, 1], 'y': [0, 1]}, value=hired, mode="gauge+number", title={'text': "Hired"}, gauge={'axis': {'range': [None, max(10, hired * 2)]}}))
        fig1.update_layout(height=200, margin=dict(l=10, r=10, t=50, b=10, pad=8))
        st.plotly_chart(fig1, use_container_width=True)
    with second_column:
        fig2 = go.Figure(go.Indicator(domain={'x': [0, 1], 'y': [0, 1]}, value=success_rate, number={'suffix': " %"}, mode="gauge+number", title={'text': "Success Rate"}, gauge={'axis': {'range': [0, 100]}}))
        fig2.update_layout(height=200, margin=dict(l=10, r=10, t=50, b=10, pad=8))
        st.plotly_chart(fig2, use_container_width=True)
    with third_column:
        fig3 = go.Figure(go.Indicator(domain={'x': [0, 1], 'y': [0, 1]}, value=apps_per_hire, mode="gauge+number", title={'text': "Applications per Hire"}, gauge={'axis': {'range': [0, max(10, apps_per_hire * 2)]}}))
        fig3.update_layout(height=200, margin=dict(l=10, r=10, t=50, b=10, pad=8))
        st.plotly_chart(fig3, use_container_width=True)
    with fourth_column:
        fig4 = go.Figure(go.Indicator(domain={'x': [0, 1], 'y': [0, 1]}, value=days_to_hire, mode="gauge+number", title={'text': "Days to Hire"}, gauge={'axis': {'range': [0, max(10, days_to_hire * 2)]}}))
        fig4.update_layout(height=200, margin=dict(l=10, r=10, t=50, b=10, pad=8))
        st.plotly_chart(fig4, use_container_width=True)

    # Chart Columns
    col1, col2, col3 = st.columns(3)

    # Recruitment Funnel
    with col1:
        st.subheader('Recruitment Funnel')
        df_recruitment_funnel_index = ['Hired', 'Applied']
        df_recruitment_funnel = pd.DataFrame(df_selection['Recruitment_Stages'].value_counts(), index=df_recruitment_funnel_index).fillna(0)
        df_recruitment_funnel = df_recruitment_funnel.cumsum().sort_values(by='Recruitment_Stages', ascending=False)
        recruitment_funnel = go.Figure(go.Funnel(y=df_recruitment_funnel.index, x=df_recruitment_funnel['Recruitment_Stages'], textposition="inside", textinfo="percent initial"))
        recruitment_funnel.update_layout(showlegend=False, yaxis_title=None)
        st.plotly_chart(recruitment_funnel, use_container_width=True)

    # Stages Pipeline Pie
    with col2:
        st.subheader('Recruitment Stages Pipeline')
        stages_pipeline_pie = go.Figure(data=[go.Pie(labels=['Applied', 'Hired'], values=df_selection['Recruitment_Stages'].value_counts(), hole=0.5)])
        stages_pipeline_pie.update_layout(legend=dict(yanchor="bottom", y=0.01, xanchor="left", x=0.01))
        stages_pipeline_pie.update_traces(hoverinfo='label+percent', textinfo='value', textfont_size=15)
        st.plotly_chart(stages_pipeline_pie, use_container_width=True)

    # Source Pie
    with col3:
        st.subheader('Source')
        source_pie = go.Figure(data=[go.Pie(labels=df_selection['Source'].unique(), values=df_selection['Source'].value_counts())])
        source_pie.update_layout(legend=dict(yanchor="bottom", y=0.01, xanchor="left", x=0.01))
        source_pie.update_traces(hoverinfo='label+value')
        st.plotly_chart(source_pie, use_container_width=True)

    # Table Columns
    col4, col5 = st.columns([2, 1])

    # Sources Performance Table
    with col4:
        st.subheader('Source Performance')
        try:
            df_source = pd.DataFrame(df_selection[['Source', 'Recruitment_Stages']])
            df_applied = df_source.groupby('Source').size().reset_index(name='# Applied')
            df_applied['% Of Applications'] = df_applied['# Applied'] / df_applied['# Applied'].sum() * 100
            df_hired = df_source[df_source['Recruitment_Stages'] == 'Hired'].groupby('Source').size().reset_index(name='# Hired')
            df_source_performance = pd.merge(df_applied, df_hired, on='Source', how='left').fillna(0)
            df_source_performance['% Of Hired'] = df_source_performance['# Hired'] / df_source_performance['# Hired'].sum() * 100 if df_source_performance['# Hired'].sum() > 0 else 0
            df_source_performance['% Of Conversion Rate'] = df_source_performance['# Hired'] / df_source_performance['# Applied'] * 100
            st.dataframe(
                df_source_performance,
                column_config={
                    "% Of Applications": st.column_config.ProgressColumn("% Of Applications", format="%.2f", min_value=0, max_value=100),
                    "% Of Hired": st.column_config.ProgressColumn("% Of Hired", format="%.2f", min_value=0, max_value=100),
                    "% Of Conversion Rate": st.column_config.ProgressColumn("% Of Conversion Rate", format="%.2f", min_value=0, max_value=100),
                },
                hide_index=True,
                use_container_width=True
            )
        except KeyError as e:
            st.write(f"⚠️ Error in Source Performance: Missing column {e}")

    # Decline Reasons Table
    with col5:
        st.subheader('Decline Reasons')
        try:
            df_decline_reasons = pd.DataFrame(df_selection[['Status']])
            df_decline_reasons['Decline_Reasons'] = df_decline_reasons['Status'].apply(lambda x: 'Pending' if x != 'Placement' else 'N/A')
            df_decline_reasons = df_decline_reasons.loc[df_decline_reasons['Status'] != 'Placement']
            df_applications = pd.DataFrame(df_decline_reasons['Decline_Reasons'].value_counts().to_frame('# Of Applications'))
            df_applications['% Of Applications'] = (df_applications['# Of Applications'] / df_applications['# Of Applications'].sum()) * 100
            st.dataframe(
                df_applications,
                column_config={"% Of Applications": st.column_config.ProgressColumn("% Of Applications", format="%.2f", min_value=0, max_value=100)},
                hide_index=False,
                use_container_width=True
            )
        except KeyError as e:
            st.write(f"⚠️ Error in Decline Reasons: Missing column {e}")