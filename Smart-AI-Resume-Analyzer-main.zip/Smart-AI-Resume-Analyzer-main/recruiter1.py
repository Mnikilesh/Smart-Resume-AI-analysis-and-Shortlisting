import streamlit as st
import joblib
import pandas as pd
import spacy
import zipfile
import re
from io import BytesIO
import tempfile
from docx import Document
import os
from pdfminer.high_level import extract_text
from concurrent.futures import ThreadPoolExecutor
import logging
from typing import List, Dict, Set, Optional

# Configure Logging
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)

# Page Configuration
st.set_page_config(layout="wide", page_title="Smart Resume AI - Recruiter Portal", initial_sidebar_state="expanded")

# Load Models
try:
    nlp = spacy.load("en_core_web_sm")
    ats_model = joblib.load("ats_model.pkl")
    vectorizer = joblib.load("tfidf_vectorizer.pkl")
except Exception as e:
    st.error(f"Failed to load models: {e}")
    logger.error(f"Model loading error: {e}")
    st.stop()

# Keyword Definitions (unchanged from original)
EDUCATION_KEYWORDS = {
    "Schooling": ["class x", "10th", "high school", "secondary school", "ssc", "matriculation", "cbse", "icse", "xth class", "xth", "10th class", "school", "tenth", "secondary", "matric", "schooling"],
    "Intermediate": ["class xii", "12th", "intermediate", "higher secondary", "hsc", "xiith class", "xiith", "12th class", "senior secondary", "pre-university", "puc", "MPC intermediate"],
    "Bachelors": ["bachelor of technology", "btech", "b.tech", "bachelor of science", "bs", "bsc", "bachelor of engineering", "be", "b.e", "undergraduate", "graduation", "degree", "b.a", "ba", "b.s", "b.com"],
    "Masters": ["master of technology", "mtech", "m.tech", "master of science", "ms", "msc", "master of business administration", "mba", "postgraduate", "m.s", "m.a", "ma"],
    "PhD": ["doctor of philosophy", "phd", "ph.d", "doctorate"],
    "Certifications": ["diploma", "associate degree", "certificate", "certification"]
}

TECHNICAL_SKILLS = {
    "Programming": ["c", "c++", "java", "python", "javascript", "ruby", "go", "r", "kotlin", "swift", "perl", "php", "scala"],
    "Web": ["html", "css", "node.js", "react", "django", "flask", "angular", "vue.js", "php", "bootstrap", "streamlit"],
    "Databases": ["mysql", "mongodb", "postgresql", "sqlite", "oracle", "sql server", "nosql"],
    "Frameworks": ["pandas", "numpy", "tensorflow", "pytorch", "scikit-learn", "spring", "django", "flask", "react", "angular", "streamlit"],
    "Cloud": ["aws", "google cloud", "azure", "heroku", "docker", "kubernetes"],
    "Tools": ["git", "github", "jenkins", "jira", "vscode", "intellij", "eclipse", "linux", "windows", "macos", "xcode", "android studio", "xampp"],
    "Mobile Development": ["android", "ios", "flutter", "react native"]
}

PROJECT_KEYWORDS = ["project", "developed", "created", "built", "implemented", "designed", "worked on", "contributed to", "participated in"]
INTERNSHIP_KEYWORDS = ["internship", "intern", "trainee", "apprentice", "work experience", "placement", "co-op", "practicum"]
SECTION_HEADERS = ["education", "experience", "skills", "projects", "internships", "certifications", "awards", "publications", "languages", "interests", "summary", "objective", "work experience", "coursework"]
SCORE_PATTERN = re.compile(r"(?i)(?:gpa|cgpa|percentage|marks|score|out of)[:\s-]*([\d\.]+(?:/\s*[\d\.]+)?%?)(?:\s*(?:out of|\/)\s*([\d\.]+))?|([\d\.]+)\s*(?:out of|\/)\s*([\d\.]+)|([\d\.]+)%", re.IGNORECASE)

# Helper Functions (unchanged from original)
def extract_text_from_file(file: BytesIO, file_type: str) -> str:
    try:
        if file_type == "application/pdf":
            return extract_text(BytesIO(file.read()))
        elif file_type == "application/vnd.openxmlformats-officedocument.wordprocessingml.document":
            doc = Document(BytesIO(file.read()))
            return "\n".join(para.text for para in doc.paragraphs)
        else:
            raise ValueError(f"Unsupported file type: {file_type}")
    except Exception as e:
        logger.error(f"Text extraction failed: {e}")
        raise

def is_resume(text: str) -> bool:
    text_lower = text.lower()
    sections = ["education", "experience", "skills", "projects", "internships"]
    section_count = sum(section in text_lower for section in sections)
    all_keywords = ([kw for category in EDUCATION_KEYWORDS.values() for kw in category] +
                    [skill for skills in TECHNICAL_SKILLS.values() for skill in skills] +
                    PROJECT_KEYWORDS + INTERNSHIP_KEYWORDS)
    keyword_count = sum(kw in text_lower for kw in all_keywords)
    return section_count >= 2 or keyword_count >= 5

def extract_sections(text: str) -> Dict[str, str]:
    lines = text.split("\n")
    sections = {}
    current_section = None
    for line in lines:
        line_lower = line.lower().strip()
        for header in SECTION_HEADERS:
            if header in line_lower and len(line_lower.split()) < 6:
                current_section = header
                sections[current_section] = []
                break
        else:
            if current_section:
                sections[current_section].append(line)
    for section in sections:
        sections[section] = "\n".join(sections[section]).strip()
    return sections

def normalize_score(score_value: str, max_value: Optional[str], education_level: str) -> Optional[float]:
    try:
        score = score_value.strip()
        if "/" in score:
            num, denom = map(float, re.split(r"\s*/\s*", score))
            return (num / denom) * 100
        elif "%" in score:
            return float(score.rstrip("%"))
        else:
            num = float(score)
            if max_value:
                return (num / float(max_value)) * 100
            if education_level in ["Bachelors", "Masters", "PhD"]:
                if 0 <= num <= 4.0:
                    return (num / 4.0) * 100
                elif 4.0 < num <= 10.0:
                    return (num / 10.0) * 100
                elif 10.0 < num <= 100.0:
                    return num
            elif education_level in ["Schooling", "Intermediate"]:
                if 0 <= num <= 10.0:
                    return (num / 10.0) * 100
                elif 10.0 < num <= 100.0:
                    return num
            return None
    except (ValueError, ZeroDivisionError) as e:
        logger.warning(f"Failed to normalize score '{score_value}': {e}")
        return None

def extract_education(text: str) -> List[Dict[str, Optional[str]]]:
    sections = extract_sections(text)
    education_text = sections.get("education", sections.get("coursework", text))
    lines = education_text.split("\n")
    education_entries = []
    current_entry = []
    for line in lines:
        line_lower = line.strip().lower()
        if line.strip():
            if any(kw in line_lower for category in EDUCATION_KEYWORDS.values() for kw in category):
                if current_entry:
                    education_entries.append("\n".join(current_entry))
                current_entry = [line]
            else:
                current_entry.append(line)
        elif current_entry:
            education_entries.append("\n".join(current_entry))
            current_entry = []
    if current_entry:
        education_entries.append("\n".join(current_entry))
    education_details = []
    for entry in education_entries:
        doc = nlp(entry)
        degree = next((cat for cat, kws in EDUCATION_KEYWORDS.items() if any(kw in entry.lower() for kw in kws)), "")
        institution = next((ent.text for ent in doc.ents if ent.label_ == "ORG"), None) or \
                      (re.search(r"(?:university|college|school|institute|academy|board)\s+of?\s+[\w\s]+", entry, re.I).group(0) if re.search(r"(?:university|college|school|institute|academy|board)\s+of?\s+[\w\s]+", entry, re.I) else "N/A")
        year_match = re.search(r"\b(?:19|20)\d{2}\s*-\s*(?:19|20)\d{2}\b|\b(?:19|20)\d{2}\b", entry)
        year = year_match.group(0) if year_match else "N/A"
        major_match = re.search(r"(?:in|major|specialization)[:\s]+([a-z\s]+)", entry, re.I)
        major = major_match.group(1).strip() if major_match else "N/A"
        score_match = SCORE_PATTERN.search(entry)
        if score_match:
            score_value = score_match.group(1) or score_match.group(3) or score_match.group(5)
            max_value = score_match.group(2) or score_match.group(4)
            normalized_score = normalize_score(score_value, max_value, degree)
            score_str = f"{score_value}" + (f"/{max_value}" if max_value else "") + (f" ({normalized_score:.1f}%)" if normalized_score is not None else "")
        else:
            score_str = "N/A"
            normalized_score = None
        education_details.append({"degree": degree, "institution": institution, "major": major, "score": score_str, "normalized_score": normalized_score, "year": year})
        logger.info(f"Extracted education: {degree} at {institution}")
    return education_details

def extract_skills(text: str, required_skills: List[str]) -> Set[str]:
    skills = set()
    text_lower = text.lower()
    for category, skill_list in TECHNICAL_SKILLS.items():
        for skill in skill_list:
            if re.search(rf"\b{re.escape(skill)}\b", text_lower):
                skills.add(skill)
    for skill in required_skills:
        if skill in text_lower:
            sections = extract_sections(text)
            relevant_sections = [sections.get("skills", ""), sections.get("experience", ""), sections.get("projects", ""), sections.get("internships", ""), sections.get("coursework", "")]
            if any(skill in sec.lower() for sec in relevant_sections) or re.search(rf"\b{re.escape(skill)}\b", text_lower):
                skills.add(skill)
    return skills

def extract_projects(text: str) -> List[Dict[str, str]]:
    sections = extract_sections(text)
    project_text = sections.get("projects", text)
    lines = project_text.split("\n")
    projects = []
    current_project = []
    for line in lines:
        line_lower = line.lower().strip()
        if (any(kw in line_lower for kw in PROJECT_KEYWORDS) or re.match(r"^\s*[-•*]\s+", line)) and line.strip():
            if current_project:
                projects.append("\n".join(current_project))
            current_project = [line]
        elif current_project and line.strip():
            current_project.append(line)
        elif current_project and not line.strip():
            projects.append("\n".join(current_project))
            current_project = []
    if current_project:
        projects.append("\n".join(current_project))
    project_details = []
    for project in projects:
        title_match = re.search(r"^\s*[-•*]?\s*(.+?)(?:[-:]\s*|$)", project)
        title = title_match.group(1).strip() if title_match else "Unnamed Project"
        techs = set(skill for skill_list in TECHNICAL_SKILLS.values() for skill in skill_list if skill in project.lower())
        tech_str = ", ".join(techs) if techs else "N/A"
        desc_match = re.search(r"(?:\n|\s{2,})(.+)", project, re.DOTALL)
        description = desc_match.group(1).strip() if desc_match else project.strip()
        duration_match = re.search(r"(?:(?:19|20)\d{2}\s*[-–]\s*(?:19|20)?\d{2})", project)
        duration = duration_match.group(0) if duration_match else "N/A"
        project_details.append({"title": title, "technologies": tech_str, "description": description, "duration": duration})
        logger.info(f"Extracted project: {title}")
    return project_details

def extract_internships(text: str) -> List[Dict[str, str]]:
    sections = extract_sections(text)
    intern_text = sections.get("internships", sections.get("experience", sections.get("work experience", text)))
    lines = intern_text.split("\n")
    internships = []
    current_internship = []
    for line in lines:
        line_lower = line.lower().strip()
        if (any(kw in line_lower for kw in INTERNSHIP_KEYWORDS) or re.match(r"^\s*[-•*]\s+", line)) and line.strip():
            if current_internship:
                internships.append("\n".join(current_internship))
            current_internship = [line]
        elif current_internship and line.strip():
            current_internship.append(line)
        elif current_internship and not line.strip():
            internships.append("\n".join(current_internship))
            current_internship = []
    if current_internship:
        internships.append("\n".join(current_internship))
    internship_details = []
    for internship in internships:
        doc = nlp(internship)
        role_match = re.search(r"^\s*[-•*]?\s*(.+?)(?:\s*(?:at|with)\s+|$)", internship)
        company_match = re.search(r"(?:at|with)\s+(.+?)(?:\s*[-:]\s*|\n|$)", internship, re.I)
        role = role_match.group(1).strip() if role_match else "Unnamed Role"
        company = company_match.group(1).strip() if company_match else "Unknown Company"
        techs = set(skill for skill_list in TECHNICAL_SKILLS.values() for skill in skill_list if skill in internship.lower())
        tech_str = ", ".join(techs) if techs else "N/A"
        desc_match = re.search(r"(?:\n|\s{2,})(.+)", internship, re.DOTALL)
        description = desc_match.group(1).strip() if desc_match else internship.strip()
        duration_match = re.search(r"(?:(?:19|20)\d{2}\s*[-–]\s*(?:19|20)?\d{2})", internship)
        duration = duration_match.group(0) if duration_match else "N/A"
        internship_details.append({"role": role, "company": company, "technologies": tech_str, "description": description, "duration": duration})
        logger.info(f"Extracted internship: {role} at {company}")
    return internship_details

def extract_experience(text: str) -> List[Dict[str, str]]:
    sections = extract_sections(text)
    experience_text = sections.get("experience", sections.get("work experience", text))
    lines = experience_text.split("\n")
    experiences = []
    current_experience = []
    for line in lines:
        line_lower = line.lower().strip()
        if (re.match(r"^\s*[-•*]\s+", line) or any(kw in line_lower for kw in ["role", "position", "job"])) and line.strip():
            if current_experience:
                experiences.append("\n".join(current_experience))
            current_experience = [line]
        elif current_experience and line.strip():
            current_experience.append(line)
        elif current_experience and not line.strip():
            experiences.append("\n".join(current_experience))
            current_experience = []
    if current_experience:
        experiences.append("\n".join(current_experience))
    experience_details = []
    for experience in experiences:
        doc = nlp(experience)
        role_match = re.search(r"^\s*[-•*]?\s*(.+?)(?:\s*(?:at|with)\s+|$)", experience)
        company_match = re.search(r"(?:at|with)\s+(.+?)(?:\s*[-:]\s*|\n|$)", experience, re.I)
        role = role_match.group(1).strip() if role_match else "Unnamed Role"
        company = company_match.group(1).strip() if company_match else next((ent.text for ent in doc.ents if ent.label_ == "ORG"), "Unknown Company")
        techs = set(skill for skill_list in TECHNICAL_SKILLS.values() for skill in skill_list if skill in experience.lower())
        tech_str = ", ".join(techs) if techs else "N/A"
        desc_match = re.search(r"(?:\n|\s{2,})(.+)", experience, re.DOTALL)
        description = desc_match.group(1).strip() if desc_match else experience.strip()
        duration_match = re.search(r"(?:(?:19|20)\d{2}\s*[-–]\s*(?:19|20)?\d{2})", experience)
        duration = duration_match.group(0) if duration_match else "N/A"
        experience_details.append({"role": role, "company": company, "technologies": tech_str, "description": description, "duration": duration})
        logger.info(f"Extracted experience: {role} at {company}")
    return experience_details

def process_file(file: BytesIO, file_name: str, file_type: str) -> tuple[str, Optional[str]]:
    try:
        text = extract_text_from_file(file, file_type)
        return file_name, text
    except ValueError as e:
        logger.error(f"Unsupported file type for {file_name}: {e}")
        st.warning(f"Skipping {file_name}: Unsupported file type.")
        return file_name, None
    except Exception as e:
        logger.error(f"Error processing {file_name}: {e}")
        st.warning(f"Skipping {file_name}: Processing error - file may be corrupted.")
        return file_name, None

def main():
    st.title("📊 Smart Resume AI - Recruiter Portal")
    st.markdown("**Analyze and shortlist candidates with precision using AI-powered resume parsing.**")

    # Sidebar: Job Criteria
    with st.sidebar:
        st.header("🔍 Job Criteria")
        min_education = st.selectbox("Minimum Education Level", ["None", "Schooling", "Intermediate", "Bachelors", "Masters", "PhD", "Certifications"], index=0)
        education_gpa = st.number_input("Minimum GPA/Percentage", min_value=0.0, max_value=100.0, value=0.0, step=0.1)
        skills_required = [s.strip().lower() for s in st.text_area("Required Skills (comma-separated)").split(",") if s.strip()]
        ats_score_threshold = st.slider("Minimum ATS Score (out of 100)", 0, 100, 50, 1)

    # File Upload
    uploaded_files = st.file_uploader("Upload Resumes (PDF, DOCX, ZIP)", type=["pdf", "docx", "zip"], accept_multiple_files=True)
    if not uploaded_files:
        st.info("Please upload resumes (PDF, DOCX, or ZIP) to begin processing.")
        return

    # Process Files
    resume_texts = []
    invalid_files = []
    with st.spinner("Processing resumes..."):
        progress_bar = st.progress(0)
        total_files = len(uploaded_files)
        processed_count = 0
        with ThreadPoolExecutor() as executor:
            for i, uploaded_file in enumerate(uploaded_files):
                if uploaded_file.type == "application/zip":
                    with tempfile.TemporaryDirectory() as temp_dir:
                        with zipfile.ZipFile(BytesIO(uploaded_file.read()), "r") as zip_ref:
                            zip_ref.extractall(temp_dir)
                        files = [os.path.join(root, f) for root, _, fs in os.walk(temp_dir) for f in fs]
                        for file_path in files:
                            file_name = os.path.basename(file_path)
                            file_type = "application/pdf" if file_path.endswith(".pdf") else "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                            with open(file_path, "rb") as f:
                                file_name, text = process_file(BytesIO(f.read()), file_name, file_type)
                                if text and is_resume(text):
                                    resume_texts.append((file_name, text))
                                    processed_count += 1
                                else:
                                    invalid_files.append(file_name)
                else:
                    file_name, text = process_file(uploaded_file, uploaded_file.name, uploaded_file.type)
                    if text and is_resume(text):
                        resume_texts.append((file_name, text))
                        processed_count += 1
                    else:
                        invalid_files.append(file_name)
                progress_bar.progress((i + 1) / total_files)
        st.success(f"Processed {processed_count} resumes successfully.")

    # Shortlist Candidates
    shortlisted_candidates = []
    education_levels = {"schooling": 1, "intermediate": 2, "bachelors": 3, "masters": 4, "phd": 5, "certifications": 6}
    for file_name, text in resume_texts:
        try:
            education = extract_education(text)
            skills = extract_skills(text, skills_required)
            projects = extract_projects(text)
            internships = extract_internships(text)
            experiences = extract_experience(text)
            text_vector = vectorizer.transform([text])
            ats_score = round(float(ats_model.predict(text_vector)[0]) * 1, 2)
            min_level = education_levels.get(min_education.lower(), 0)
            meets_education = min_education == "None" or any(education_levels.get(e["degree"].lower(), 0) >= min_level for e in education)
            meets_gpa = education_gpa == 0.0 or any(e["normalized_score"] is not None and e["normalized_score"] >= education_gpa for e in education)
            meets_skills = not skills_required or all(skill in text.lower() for skill in skills_required)
            meets_ats = ats_score >= ats_score_threshold
            if meets_education and meets_gpa and meets_skills and meets_ats:
                shortlisted_candidates.append({
                    "Candidate Name": file_name,
                    "Education": "; ".join(f"{e['degree']} - {e['institution']} (Major: {e['major']}, Score: {e['score']}, Year: {e['year']})" for e in education) or "N/A",
                    "Skills": ", ".join(skills) or "N/A",
                    "Projects": "; ".join(f"{p['title']} (Tech: {p['technologies']}, Duration: {p['duration']}): {p['description']}" for p in projects) or "N/A",
                    "Internships": "; ".join(f"{i['role']} at {i['company']} (Tech: {i['technologies']}, Duration: {i['duration']}): {i['description']}" for i in internships) or "N/A",
                    "Experience": "; ".join(f"{e['role']} at {e['company']} (Tech: {e['technologies']}, Duration: {e['duration']}): {e['description']}" for e in experiences) or "N/A",
                    "ATS Score": ats_score
                })
        except Exception as e:
            logger.error(f"Error processing {file_name}: {e}")
            invalid_files.append(file_name)

    # Store and Display Results
    if invalid_files:
        st.error(f"Invalid or unprocessable files: {', '.join(set(invalid_files))}")
    if shortlisted_candidates:
        df = pd.DataFrame(shortlisted_candidates)
        df = df.sort_values(by="ATS Score", ascending=False)
        st.session_state['shortlisted_candidates'] = df  # Store in session state
        st.subheader("Shortlisted Candidates")
        st.dataframe(df.style.format({"ATS Score": "{:.2f}"}))
        st.info(f"Total shortlisted candidates: {len(df)}")
        st.info(f"Average ATS score: {df['ATS Score'].mean():.2f}")
        csv_buffer = BytesIO()
        df.to_csv(csv_buffer, index=False)
        st.download_button(label="Download Shortlist CSV", data=csv_buffer.getvalue(), file_name="shortlisted_candidates.csv", mime="text/csv")
    else:
        st.warning("No candidates match the specified criteria.")

if __name__ == "__main__":
    main()