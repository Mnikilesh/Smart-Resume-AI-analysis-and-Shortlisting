import streamlit as st
import joblib
import pandas as pd
import spacy
import zipfile
import re
from io import BytesIO
import tempfile
from docx import Document
import os
from pdfminer.high_level import extract_text
from concurrent.futures import ThreadPoolExecutor
import logging
from typing import List, Dict, Set, Optional
import plotly.graph_objects as go
import datetime
import numpy as np

# Configure Logging
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)

# Page Configuration
st.set_page_config(layout="wide", page_title="Smart Resume AI - Recruiter Portal", initial_sidebar_state="expanded")

# Load Models
try:
    nlp = spacy.load("en_core_web_sm")
    ats_model = joblib.load("ats_model.pkl")
    vectorizer = joblib.load("tfidf_vectorizer.pkl")
except Exception as e:
    st.error(f"Failed to load models: {e}")
    logger.error(f"Model loading error: {e}")
    st.stop()

# Keyword Definitions
EDUCATION_KEYWORDS = {
    "Schooling": ["class x", "10th", "high school", "secondary school", "ssc", "matriculation", "cbse", "icse", "xth class", "xth", "10th class", "school", "tenth", "secondary", "matric", "schooling"],
    "Intermediate": ["class xii", "12th", "intermediate", "higher secondary", "hsc", "xiith class", "xiith", "12th class", "senior secondary", "pre-university", "puc", "mpc intermediate"],
    "Bachelors": ["bachelor of technology", "btech", "b.tech", "bachelor of science", "bs", "bsc", "bachelor of engineering", "be", "b.e", "undergraduate", "graduation", "degree", "b.a", "ba", "b.s", "b.com"],
    "Masters": ["master of technology", "mtech", "m.tech", "master of science", "ms", "msc", "master of business administration", "mba", "postgraduate", "m.s", "m.a", "ma"],
    "PhD": ["doctor of philosophy", "phd", "ph.d", "doctorate"],
    "Certifications": ["diploma", "associate degree", "certificate", "certification"]
}

TECHNICAL_SKILLS = {
    "Programming": ["c", "c++", "java", "python", "javascript", "ruby", "go", "r", "kotlin", "swift", "perl", "php", "scala"],
    "Web": ["html", "css", "node.js", "react", "django", "flask", "angular", "vue.js", "php", "bootstrap", "streamlit"],
    "Databases": ["mysql", "mongodb", "postgresql", "sqlite", "oracle", "sql server", "nosql"],
    "Frameworks": ["pandas", "numpy", "tensorflow", "pytorch", "scikit-learn", "spring", "django", "flask", "react", "angular", "streamlit"],
    "Cloud": ["aws", "google cloud", "azure", "heroku", "docker", "kubernetes"],
    "Tools": ["git", "github", "jenkins", "jira", "vscode", "intellij", "eclipse", "linux", "windows", "macos", "xcode", "android studio", "xampp"],
    "Mobile Development": ["android", "ios", "flutter", "react native"]
}

PROJECT_KEYWORDS = ["project", "developed", "created", "built", "implemented", "designed", "worked on", "contributed to", "participated in"]
INTERNSHIP_KEYWORDS = ["internship", "intern", "trainee", "apprentice", "work experience", "placement", "co-op", "practicum"]
SECTION_HEADERS = ["education", "experience", "skills", "projects", "internships", "certifications", "awards", "publications", "languages", "interests", "summary", "objective", "work experience", "coursework"]
SCORE_PATTERN = re.compile(r"(?i)(?:gpa|cgpa|percentage|marks|score|out of)[:\s-]*([\d\.]+(?:/\s*[\d\.]+)?%?)(?:\s*(?:out of|\/)\s*([\d\.]+))?|([\d\.]+)\s*(?:out of|\/)\s*([\d\.]+)|([\d\.]+)%", re.IGNORECASE)

# Helper Functions
def extract_text_from_file(file: BytesIO, file_type: str) -> str:
    try:
        if file_type == "application/pdf":
            return extract_text(BytesIO(file.read()))
        elif file_type == "application/vnd.openxmlformats-officedocument.wordprocessingml.document":
            doc = Document(BytesIO(file.read()))
            return "\n".join(para.text for para in doc.paragraphs)
        else:
            raise ValueError(f"Unsupported file type: {file_type}")
    except Exception as e:
        logger.error(f"Text extraction failed: {e}")
        raise

def is_resume(text: str) -> bool:
    text_lower = text.lower()
    sections = ["education", "experience", "skills", "projects", "internships"]
    section_count = sum(section in text_lower for section in sections)
    all_keywords = ([kw for category in EDUCATION_KEYWORDS.values() for kw in category] +
                    [skill for skills in TECHNICAL_SKILLS.values() for skill in skills] +
                    PROJECT_KEYWORDS + INTERNSHIP_KEYWORDS)
    keyword_count = sum(kw in text_lower for kw in all_keywords)
    return section_count >= 2 or keyword_count >= 5

def extract_sections(text: str) -> Dict[str, str]:
    lines = text.split("\n")
    sections = {}
    current_section = None
    for line in lines:
        line_lower = line.lower().strip()
        for header in SECTION_HEADERS:
            if header in line_lower and len(line_lower.split()) < 6:
                current_section = header
                sections[current_section] = []
                break
        else:
            if current_section:
                sections[current_section].append(line)
    for section in sections:
        sections[section] = "\n".join(sections[section]).strip()
    return sections

def normalize_score(score_str: str, education_level: str) -> Optional[float]:
    """Normalize scores to percentage for consistent comparison."""
    score_str = score_str.lower()
    try:
        if '%' in score_str:
            match = re.search(r'(\d+\.?\d*)%', score_str)
            return float(match.group(1)) if match else None
        match = re.search(r'(\d+\.?\d*)\s*/\s*(\d+\.?\d*)', score_str)
        if match:
            score, max_score = float(match.group(1)), float(match.group(2))
            if max_score == 4.0:
                return (score / 4.0) * 100
            elif max_score == 10.0:
                return (score / 10.0) * 100
            return (score / max_score) * 100
        match = re.search(r'(gpa|cgpa|score|marks)[:\s-]*(\d+\.?\d*)', score_str)
        if match:
            score = float(match.group(2))
            if score <= 4.0:
                return (score / 4.0) * 100
            elif score <= 10.0:
                return (score / 10.0) * 100
            return score if score <= 100 else None
        match = re.search(r'(\d+\.?\d*)', score_str)
        if match:
            score = float(match.group(1))
            if education_level in ["Schooling", "Intermediate"]:
                if score <= 10.0:
                    return (score / 10.0) * 100
                return score if score <= 100 else None
            else:
                if score <= 4.0:
                    return (score / 4.0) * 100
                elif score <= 10.0:
                    return (score / 10.0) * 100
                return score if score <= 100 else None
        return None
    except (ValueError, ZeroDivisionError) as e:
        logger.warning(f"Failed to normalize score '{score_str}': {e}")
        return None

def extract_education(text: str) -> List[Dict[str, Optional[str]]]:
    sections = extract_sections(text)
    education_text = sections.get("education", sections.get("coursework", text))
    lines = education_text.split("\n")
    education_entries = []
    current_entry = []
    for line in lines:
        line_lower = line.strip().lower()
        if line.strip():
            if any(kw in line_lower for category in EDUCATION_KEYWORDS.values() for kw in category):
                if current_entry:
                    education_entries.append("\n".join(current_entry))
                current_entry = [line]
            else:
                current_entry.append(line)
        elif current_entry:
            education_entries.append("\n".join(current_entry))
            current_entry = []
    if current_entry:
        education_entries.append("\n".join(current_entry))
    education_details = []
    for entry in education_entries:
        doc = nlp(entry)
        degree = next((cat for cat, kws in EDUCATION_KEYWORDS.items() if any(kw in entry.lower() for kw in kws)), "")
        institution = next((ent.text for ent in doc.ents if ent.label_ == "ORG"), None) or \
                      (re.search(r"(?:university|college|school|institute|academy|board)\s+of?\s+[\w\s]+", entry, re.I).group(0) if re.search(r"(?:university|college|school|institute|academy|board)\s+of?\s+[\w\s]+", entry, re.I) else " ")
        year_match = re.search(r"\b(?:19|20)\d{2}\s*-\s*(?:19|20)\d{2}\b|\b(?:19|20)\d{2}\b", entry)
        year = year_match.group(0) if year_match else ""
        major_match = re.search(r"(?:in|major|specialization)[:\s]+([a-z\s]+)", entry, re.I)
        major = major_match.group(1).strip() if major_match else ""
        score_match = SCORE_PATTERN.search(entry)
        if score_match:
            score_str = score_match.group(0)
            normalized_score = normalize_score(score_str, degree)
            score_display = f"{score_str} ({normalized_score:.1f}%)" if normalized_score is not None else score_str
        else:
            score_display = " "
            normalized_score = None
        education_details.append({"degree": degree, "institution": institution, "major": major, "score": score_display, "normalized_score": normalized_score, "year": year})
        logger.info(f"Extracted education: {degree} at {institution}")
    return education_details

def extract_skills(text: str, required_skills: List[str]) -> Set[str]:
    skills = set()
    text_lower = text.lower()
    for category, skill_list in TECHNICAL_SKILLS.items():
        for skill in skill_list:
            if re.search(rf"\b{re.escape(skill)}\b", text_lower):
                skills.add(skill)
    for skill in required_skills:
        if re.search(rf"\b{re.escape(skill)}\b", text_lower):
            skills.add(skill)
    return skills

def extract_projects(text: str) -> List[Dict[str, str]]:
    sections = extract_sections(text)
    project_text = sections.get("projects", text)
    lines = project_text.split("\n")
    projects = []
    current_project = []
    for line in lines:
        line_lower = line.lower().strip()
        if (any(kw in line_lower for kw in PROJECT_KEYWORDS) or re.match(r"^\s*[-•*]\s+", line)) and line.strip():
            if current_project:
                projects.append("\n".join(current_project))
            current_project = [line]
        elif current_project and line.strip():
            current_project.append(line)
        elif current_project and not line.strip():
            projects.append("\n".join(current_project))
            current_project = []
    if current_project:
        projects.append("\n".join(current_project))
    project_details = []
    for project in projects:
        title_match = re.search(r"^\s*[-•*]?\s*(.+?)(?:[-:]\s*|$)", project)
        title = title_match.group(1).strip() if title_match else "Unnamed Project"
        techs = set(skill for skill_list in TECHNICAL_SKILLS.values() for skill in skill_list if skill in project.lower())
        tech_str = ", ".join(techs) if techs else "N/A"
        desc_match = re.search(r"(?:\n|\s{2,})(.+)", project, re.DOTALL)
        description = desc_match.group(1).strip() if desc_match else project.strip()
        duration_match = re.search(r"(?:(?:19|20)\d{2}\s*[-–]\s*(?:19|20)?\d{2})", project)
        duration = duration_match.group(0) if duration_match else " "
        project_details.append({"title": title, "technologies": tech_str, "description": description, "duration": duration})
        logger.info(f"Extracted project: {title}")
    return project_details

def extract_internships(text: str) -> List[Dict[str, str]]:
    sections = extract_sections(text)
    intern_text = sections.get("internships", sections.get("experience", sections.get("work experience", text)))
    lines = intern_text.split("\n")
    internships = []
    current_internship = []
    for line in lines:
        line_lower = line.lower().strip()
        if (any(kw in line_lower for kw in INTERNSHIP_KEYWORDS) or re.match(r"^\s*[-•*]\s+", line)) and line.strip():
            if current_internship:
                internships.append("\n".join(current_internship))
            current_internship = [line]
        elif current_internship and line.strip():
            current_internship.append(line)
        elif current_internship and not line.strip():
            internships.append("\n".join(current_internship))
            current_internship = []
    if current_internship:
        internships.append("\n".join(current_internship))
    internship_details = []
    for internship in internships:
        doc = nlp(internship)
        role_match = re.search(r"^\s*[-•*]?\s*(.+?)(?:\s*(?:at|with)\s+|$)", internship)
        company_match = re.search(r"(?:at|with)\s+(.+?)(?:\s*[-:]\s*|\n|$)", internship, re.I)
        role = role_match.group(1).strip() if role_match else "Unnamed Role"
        company = company_match.group(1).strip() if company_match else next((ent.text for ent in doc.ents if ent.label_ == "ORG"), "Unknown Company")
        techs = set(skill for skill_list in TECHNICAL_SKILLS.values() for skill in skill_list if skill in internship.lower())
        tech_str = ", ".join(techs) if techs else "N/A"
        desc_match = re.search(r"(?:\n|\s{2,})(.+)", internship, re.DOTALL)
        description = desc_match.group(1).strip() if desc_match else internship.strip()
        duration_match = re.search(r"(?:(?:19|20)\d{2}\s*[-–]\s*(?:19|20)?\d{2})", internship)
        duration = duration_match.group(0) if duration_match else " "
        internship_details.append({"role": role, "company": company, "technologies": tech_str, "description": description, "duration": duration})
        logger.info(f"Extracted internship: {role} at {company}")
    return internship_details

def extract_experience(text: str) -> List[Dict[str, str]]:
    sections = extract_sections(text)
    experience_text = sections.get("experience", sections.get("work experience", text))
    lines = experience_text.split("\n")
    experiences = []
    current_experience = []
    for line in lines:
        line_lower = line.lower().strip()
        if (re.match(r"^\s*[-•*]\s+", line) or any(kw in line_lower for kw in ["role", "position", "job"])) and line.strip():
            if current_experience:
                experiences.append("\n".join(current_experience))
            current_experience = [line]
        elif current_experience and line.strip():
            current_experience.append(line)
        elif current_experience and not line.strip():
            experiences.append("\n".join(current_experience))
            current_experience = []
    if current_experience:
        experiences.append("\n".join(current_experience))
    experience_details = []
    for experience in experiences:
        doc = nlp(experience)
        role_match = re.search(r"^\s*[-•*]?\s*(.+?)(?:\s*(?:at|with)\s+|$)", experience)
        company_match = re.search(r"(?:at|with)\s+(.+?)(?:\s*[-:]\s*|\n|$)", experience, re.I)
        role = role_match.group(1).strip() if role_match else "Unnamed Role"
        company = company_match.group(1).strip() if company_match else next((ent.text for ent in doc.ents if ent.label_ == "ORG"), "Unknown Company")
        techs = set(skill for skill_list in TECHNICAL_SKILLS.values() for skill in skill_list if skill in experience.lower())
        tech_str = ", ".join(techs) if techs else "N/A"
        desc_match = re.search(r"(?:\n|\s{2,})(.+)", experience, re.DOTALL)
        description = desc_match.group(1).strip() if desc_match else experience.strip()
        duration_match = re.search(r"(?:(?:19|20)\d{2}\s*[-–]\s*(?:19|20)?\d{2})", experience)
        duration = duration_match.group(0) if duration_match else " "
        experience_details.append({"role": role, "company": company, "technologies": tech_str, "description": description, "duration": duration})
        logger.info(f"Extracted experience: {role} at {company}")
    return experience_details

def process_file(file: BytesIO, file_name: str, file_type: str) -> tuple[str, Optional[str]]:
    try:
        text = extract_text_from_file(file, file_type)
        return file_name, text
    except ValueError as e:
        logger.error(f"Unsupported file type for {file_name}: {e}")
        st.warning(f"Skipping {file_name}: Unsupported file type.")
        return file_name, None
    except Exception as e:
        logger.error(f"Error processing {file_name}: {e}")
        st.warning(f"Skipping {file_name}: Processing error - file may be corrupted.")
        return file_name, None

# Login Page
def login_page():
    with st.form("login"):
        st.markdown("#### Enter your credentials")
        email = st.text_input("Email")
        password = st.text_input("Password", type="password")
        submit = st.form_submit_button("Login")
        if submit:
            if email == "admin" and password == "password":  # Replace with secure authentication in production
                st.session_state['logged_in'] = True
                st.rerun()
            else:
                st.error("Login failed: Invalid email or password")

# Parse Job Criteria from Query (Corrected)
def parse_job_criteria(query: str) -> Dict[str, any]:
    """Parse job criteria from the user query, handling education levels, scores, skills, and ATS threshold."""
    education_levels = ["schooling", "intermediate", "bachelors", "masters", "phd", "certifications"]
    pattern = r"(\b" + "|".join(education_levels) + r"\b)\s+(?:above|with|having)?\s*(\d+\.?\d*)\s*(%|gpa)?"
    matches = re.findall(pattern, query.lower(), re.I)
    education_requirements = {}
    for match in matches:
        level, score_str, unit = match
        try:
            score = float(score_str)
            if unit == '%':
                required_percentage = score
            elif unit == 'gpa':
                if score <= 4.0:
                    required_percentage = (score / 4.0) * 100
                else:
                    required_percentage = (score / 10.0) * 100
            else:
                if level in ["schooling", "intermediate"]:
                    required_percentage = score
                else:
                    if score <= 4.0:
                        required_percentage = (score / 4.0) * 100
                    else:
                        required_percentage = (score / 10.0) * 100
            education_requirements[level] = required_percentage
        except ValueError:
            logger.warning(f"Invalid score value '{score_str}' for {level}")

    # Updated regex to capture various skill phrases
    skills_match = re.search(r"(?:skills in|skills like|proficient in|knowledge of)\s+([\w\s,]+?)(?:and ats|ats|$)", query, re.I)
    skills_required = [s.strip().lower() for s in skills_match.group(1).strip().split(",")] if skills_match else []

    ats_match = re.search(r"ats score above (\d+)", query, re.I)
    ats_score_threshold = int(ats_match.group(1)) if ats_match else 0

    return {
        "education_requirements": education_requirements,
        "skills_required": skills_required,
        "ats_score_threshold": ats_score_threshold
    }

# Dashboard Page
def dashboard_page():
    if st.button("Back to Portal", key="back_button"):
        st.session_state['show_dashboard'] = False
        st.rerun()

    st.header(":bar_chart: Recruitment Dashboard")
    st.markdown("Visualize recruitment insights and track candidate progress.")

    uploaded_file = st.file_uploader('Upload your CSV file here', type='csv')
    if uploaded_file is not None:
        try:
            df_data = pd.read_csv(uploaded_file, encoding_errors='ignore')
            total_candidates = st.number_input("Enter the total number of candidates considered:", min_value=0, value=0)
            st.session_state['shortlisted_candidates'] = df_data
            st.session_state['total_candidates'] = total_candidates
        except Exception as e:
            st.error(f"Error parsing CSV file: {e}")
            return

    if 'shortlisted_candidates' in st.session_state and 'total_candidates' in st.session_state:
        df_data = st.session_state['shortlisted_candidates'].copy()
        total_candidates = st.session_state['total_candidates']
    else:
        st.write("No data available. Please upload a CSV file or process resumes first.")
        return

    st.subheader("Shortlisting Metrics")
    shortlisted_count = len(df_data)
    percentage_shortlisted = (shortlisted_count / total_candidates * 100) if total_candidates > 0 else 0
    col1, col2, col3 = st.columns(3)
    with col1:
        st.metric("Total Candidates", total_candidates)
    with col2:
        st.metric("Shortlisted Candidates", shortlisted_count)
    with col3:
        st.metric("Percentage Shortlisted", f"{percentage_shortlisted:.2f}%")

    st.subheader("Recruitment Stages Distribution")
    if 'Recruitment_Stages' in df_data.columns:
        fig_stages = go.Figure(data=[go.Histogram(x=df_data['Recruitment_Stages'], nbinsx=10, name='Recruitment Stages')])
        fig_stages.update_layout(xaxis_title="Recruitment Stages", yaxis_title="Count")
        st.plotly_chart(fig_stages, use_container_width=True)
    else:
        st.write("Recruitment_Stages column not found.")

    st.subheader("Top Sources Among Candidates")
    if 'Source' in df_data.columns:
        top_sources = df_data['Source'].value_counts().head(10)
        fig_sources = go.Figure(data=[go.Bar(x=top_sources.index, y=top_sources.values, name='Source Count')])
        fig_sources.update_layout(xaxis_title="Sources", yaxis_title="Number of Candidates")
        st.plotly_chart(fig_sources, use_container_width=True)
    else:
        st.write("Source column not found.")

    col1, col2 = st.columns(2)
    try:
        df_data["Application_Date"] = pd.to_datetime(df_data["Application_Date"])
        startDate = pd.to_datetime(df_data["Application_Date"]).min()
        endDate = pd.to_datetime(df_data["Application_Date"]).max()
        with col1:
            date1 = pd.to_datetime(st.date_input("Start Date", startDate))
        with col2:
            date2 = pd.to_datetime(st.date_input("End Date", endDate))
        df_data = df_data[(df_data["Application_Date"] >= date1) & (df_data["Application_Date"] <= date2)]
    except Exception as e:
        st.write(f'⚠️ Error with date filter: {e}')

    st.sidebar.header('Filter Here:')
    filters = {}
    for col in ['Language', 'Location', 'Gender', 'Company']:
        if col in df_data.columns:
            filters[col] = st.sidebar.multiselect(col, options=df_data[col].unique(), default=df_data[col].unique())
        else:
            filters[col] = []

    df_selection = df_data.copy()
    for col in filters:
        if filters[col]:
            df_selection = df_selection[df_selection[col].isin(filters[col])]

    st.subheader("Recruitment KPIs")
    hired = df_selection['Recruitment_Stages'].value_counts().get('Hired', 0) if 'Recruitment_Stages' in df_selection.columns else 0
    apps_per_hire = len(df_selection) / hired if hired > 0 else 0
    try:
        df_days_to_hire = df_selection.loc[df_selection['Recruitment_Stages'] == 'Hired']
        df_days_to_hire[['Application_Date', 'Hiring_Date']] = df_days_to_hire[['Application_Date', 'Hiring_Date']].apply(pd.to_datetime)
        days_to_hire = (df_days_to_hire['Hiring_Date'] - df_days_to_hire['Application_Date']).dt.days.mean().round()
    except Exception:
        days_to_hire = 0
    success_rate = (df_selection['Status'].value_counts().get('Placement', 0) / hired * 100) if ('Status' in df_selection.columns and hired > 0) else 0

    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.metric("Hired", hired)
    with col2:
        st.metric("Success Rate", f"{success_rate:.2f}%")
    with col3:
        st.metric("Apps per Hire", f"{apps_per_hire:.2f}")
    with col4:
        st.metric("Days to Hire", int(days_to_hire) if days_to_hire else 0)

    col1, col2, col3 = st.columns(3)
    with col1:
        st.subheader("Recruitment Funnel")
        if 'Recruitment_Stages' in df_selection.columns:
            stages = ['Applied', 'Hired']
            counts = [df_selection['Recruitment_Stages'].value_counts().get(stage, 0) for stage in stages]
            fig_funnel = go.Figure(go.Funnel(y=stages, x=counts))
            st.plotly_chart(fig_funnel, use_container_width=True)
    with col2:
        st.subheader("Stages Pipeline")
        if 'Recruitment_Stages' in df_selection.columns:
            fig_pie = go.Figure(data=[go.Pie(labels=['Applied', 'Hired'], values=df_selection['Recruitment_Stages'].value_counts(), hole=0.5)])
            st.plotly_chart(fig_pie, use_container_width=True)
    with col3:
        st.subheader("Source Distribution")
        if 'Source' in df_selection.columns:
            fig_pie = go.Figure(data=[go.Pie(labels=df_selection['Source'].unique(), values=df_selection['Source'].value_counts())])
            st.plotly_chart(fig_pie, use_container_width=True)

    col4, col5 = st.columns([2, 1])
    with col4:
        st.subheader('Source Performance')
        try:
            df_source = pd.DataFrame(df_selection[['Source', 'Recruitment_Stages']])
            df_applied = df_source.groupby('Source').size().reset_index(name='# Applied')
            df_applied['% Of Applications'] = df_applied['# Applied'] / df_applied['# Applied'].sum() * 100
            df_hired = df_source[df_source['Recruitment_Stages'] == 'Hired'].groupby('Source').size().reset_index(name='# Hired')
            df_source_performance = pd.merge(df_applied, df_hired, on='Source', how='left').fillna(0)
            df_source_performance['% Of Hired'] = df_source_performance['# Hired'] / df_source_performance['# Hired'].sum() * 100 if df_source_performance['# Hired'].sum() > 0 else 0
            df_source_performance['% Of Conversion Rate'] = df_source_performance['# Hired'] / df_source_performance['# Applied'] * 100
            st.dataframe(
                df_source_performance,
                column_config={
                    "% Of Applications": st.column_config.ProgressColumn("% Of Applications", format="%.2f", min_value=0, max_value=100),
                    "% Of Hired": st.column_config.ProgressColumn("% Of Hired", format="%.2f", min_value=0, max_value=100),
                    "% Of Conversion Rate": st.column_config.ProgressColumn("% Of Conversion Rate", format="%.2f", min_value=0, max_value=100),
                },
                hide_index=True,
                use_container_width=True
            )
        except KeyError as e:
            st.write(f"⚠️ Error in Source Performance: Missing column {e}")

    with col5:
        st.subheader('Decline Reasons')
        try:
            df_decline_reasons = pd.DataFrame(df_selection[['Status', 'Decline_Reasons']])
            df_decline_reasons['Decline_Reasons'] = df_decline_reasons.apply(
                lambda row: row['Decline_Reasons'] if row['Status'] != 'Placement' and pd.notna(row['Decline_Reasons']) else 'Pending' if row['Status'] != 'Placement' else 'N/A', axis=1)
            df_decline_reasons = df_decline_reasons.loc[df_decline_reasons['Status'] != 'Placement']
            df_applications = pd.DataFrame(df_decline_reasons['Decline_Reasons'].value_counts().to_frame('# Of Applications'))
            df_applications['% Of Applications'] = (df_applications['# Of Applications'] / df_applications['# Of Applications'].sum()) * 100
            st.dataframe(
                df_applications,
                column_config={"% Of Applications": st.column_config.ProgressColumn("% Of Applications", format="%.2f", min_value=0, max_value=100)},
                hide_index=False,
                use_container_width=True
            )
        except KeyError as e:
            st.write(f"⚠️ Error in Decline Reasons: Missing column {e}")

# Main Function
def main():
    st.markdown(
        """
        <style>
        .stButton>button {
            background-color: transparent;
            color: #1f77b4;
            border: 1px solid #1f77b4;
            width: 100%;
            padding: 10px;
            font-size: 16px;
        }
        .stButton>button:hover {
            background-color: #e6f7ff;
        }
        </style>
        """,
        unsafe_allow_html=True
    )

    if 'logged_in' not in st.session_state:
        st.session_state['logged_in'] = False

    if not st.session_state['logged_in']:
        login_page()
    else:
        st.title("📊 Smart Resume AI - Recruiter Portal")
        st.markdown("**Analyze and shortlist candidates with precision using AI-powered resume parsing.**")

        with st.sidebar:
            st.header("Navigation")
            if st.button("Dashboard", key="dashboard_button"):
                st.session_state['show_dashboard'] = True
            else:
                st.session_state['show_dashboard'] = st.session_state.get('show_dashboard', False)

            st.header("🔍 Job Criteria")
            query = st.text_area(
                "Enter job criteria",
                placeholder="Type your criteria here...",
                help="Specify education levels with scores (e.g., 'schooling 80%', 'bachelor's GPA 7.5'), skills (e.g., 'skills in Python, Java'), and ATS threshold (e.g., 'ATS score above 70')."
            )

        if st.session_state.get('show_dashboard', False):
            dashboard_page()
        else:
            # Initialize file_uploader_key if it doesn't exist
            if 'file_uploader_key' not in st.session_state:
                st.session_state['file_uploader_key'] = 0

            # Use a dynamic key for the file uploader to reset it when cleared
            uploaded_files = st.file_uploader(
                "Upload Resumes (PDF or DOCX)",
                type=["pdf", "docx"],
                accept_multiple_files=True,
                key=f"file_uploader_{st.session_state['file_uploader_key']}"
            )

            # Clear button resets the file uploader and optionally clears results
            if st.button("Clear Uploaded Files"):
                st.session_state['file_uploader_key'] += 1
                # Optionally clear processed results
                if 'shortlisted_candidates' in st.session_state:
                    del st.session_state['shortlisted_candidates']
                if 'total_candidates' in st.session_state:
                    del st.session_state['total_candidates']
                st.rerun()

            if not uploaded_files:
                st.info("Please upload resumes (PDF or DOCX) to begin processing.")
                return

            # Process Files
            resume_texts = []
            invalid_files = []
            with st.spinner("Processing resumes..."):
                progress_bar = st.progress(0)
                total_files = len(uploaded_files)
                processed_count = 0
                with ThreadPoolExecutor() as executor:
                    for i, uploaded_file in enumerate(uploaded_files):
                        if uploaded_file.type == "application/zip":
                            with tempfile.TemporaryDirectory() as temp_dir:
                                try:
                                    with zipfile.ZipFile(BytesIO(uploaded_file.read()), "r") as zip_ref:
                                        zip_ref.extractall(temp_dir)
                                    files = [os.path.join(root, f) for root, _, fs in os.walk(temp_dir) for f in fs if f.lower().endswith(('.pdf', '.docx'))]
                                    for file_path in files:
                                        file_name = os.path.basename(file_path)
                                        file_type = "application/pdf" if file_path.lower().endswith(".pdf") else "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                                        with open(file_path, "rb") as f:
                                            file_name, text = process_file(BytesIO(f.read()), file_name, file_type)
                                            if text and is_resume(text):
                                                resume_texts.append((file_name, text))
                                                processed_count += 1
                                            else:
                                                invalid_files.append(file_name)
                                except zipfile.BadZipFile as e:
                                    logger.error(f"Error extracting ZIP file {uploaded_file.name}: {e}")
                                    st.warning(f"Skipping {uploaded_file.name}: Invalid or corrupted ZIP file.")
                                    invalid_files.append(uploaded_file.name)
                        else:
                            file_name, text = process_file(uploaded_file, uploaded_file.name, uploaded_file.type)
                            if text and is_resume(text):
                                resume_texts.append((file_name, text))
                                processed_count += 1
                            else:
                                invalid_files.append(file_name)
                        progress_bar.progress((i + 1) / total_files)
                st.success(f"Processed {processed_count} resumes successfully.")

            # Parse Job Criteria
            criteria = parse_job_criteria(query) if query else {"education_requirements": {}, "skills_required": [], "ats_score_threshold": 0}
            education_requirements = criteria["education_requirements"]
            skills_required = criteria["skills_required"]
            ats_score_threshold = criteria["ats_score_threshold"]

            # Shortlist Candidates
            shortlisted_candidates = []
            for file_name, text in resume_texts:
                try:
                    education = extract_education(text)
                    skills = extract_skills(text, skills_required)
                    projects = extract_projects(text)
                    internships = extract_internships(text)
                    experiences = extract_experience(text)
                    text_vector = vectorizer.transform([text])
                    # Corrected ATS score scaling (assuming model predicts 0-1, scale to 0-100)
                    ats_score = round(float(ats_model.predict(text_vector)[0]) * 1, 2)  # Adjusted scaling
                    meets_education = not education_requirements or all(
                        any(e["degree"].lower() == level and e["normalized_score"] is not None and e["normalized_score"] >= req_score
                            for e in education)
                        for level, req_score in education_requirements.items()
                    )
                    meets_skills = not skills_required or all(req_skill.lower() in [skill.lower() for skill in skills] for req_skill in skills_required)
                    meets_ats = ats_score >= ats_score_threshold
                    candidate_data = {
                        "Candidate Name": file_name,
                        "Education": "; ".join(f"{e['degree']} - {e['institution']} (Major: {e['major']}, Score: {e['score']}, Year: {e['year']})" for e in education) or "N/A",
                        "Skills": ", ".join(skills) or "N/A",
                        "Projects": "; ".join(f"{p['title']} (Tech: {p['technologies']}, Duration: {p['duration']}): {p['description']}" for p in projects) or "N/A",
                        "Internships": "; ".join(f"{i['role']} at {i['company']} (Tech: {i['technologies']}, Duration: {i['duration']}): {i['description']}" for i in internships) or "N/A",
                        "Experience": "; ".join(f"{e['role']} at {e['company']} (Tech: {e['technologies']}, Duration: {e['duration']}): {e['description']}" for e in experiences) or "N/A",
                        "ATS Score": ats_score
                    }
                    if meets_education and meets_skills and meets_ats:
                        candidate_data["Shortlist Data"] = "Accepted"
                        shortlisted_candidates.append(candidate_data)
                except Exception as e:
                    logger.error(f"Error processing {file_name}: {e}")
                    invalid_files.append(file_name)

            # Store and Display Results
            if invalid_files:
                st.error(f"Invalid or unprocessable files: {', '.join(set(invalid_files))}")
            if shortlisted_candidates:
                df = pd.DataFrame(shortlisted_candidates)
                df['Application_Date'] = pd.to_datetime(datetime.datetime.now())
                df['Recruitment_Stages'] = df['ATS Score'].apply(lambda x: 'Hired' if x >= 75 else 'Applied')
                df['Hiring_Date'] = df['Application_Date'] + pd.Timedelta(days=30)
                df['Status'] = df['Recruitment_Stages'].apply(lambda x: 'Placement' if x == 'Hired' else 'Pending')
                df['Source'] = 'Resume AI'
                df['Company'] = 'Unknown'
                df['Language'] = 'English'
                df['Location'] = 'Unknown'
                df['Gender'] = 'Unknown'
                df = df.sort_values(by="ATS Score", ascending=False)
                st.session_state['shortlisted_candidates'] = df
                st.session_state['total_candidates'] = len(resume_texts)
                st.subheader("Shortlisted Candidates")
                st.dataframe(df.style.format({"ATS Score": "{:.2f}"}))
                st.info(f"Total shortlisted candidates: {len(df)}")
                st.info(f"Average ATS score: {df['ATS Score'].mean():.2f}")
                csv_buffer = BytesIO()
                df.to_csv(csv_buffer, index=False)
                st.download_button(label="Download Shortlist CSV", data=csv_buffer.getvalue(), file_name="shortlisted_candidates.csv", mime="text/csv")
            else:
                st.warning("No candidates match the specified criteria.")

if __name__ == "__main__":
    main()